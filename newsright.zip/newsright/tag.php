<?php get_header(); ?>

<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">
				<div class="main">
				
					<?php do_action('before_main_content'); ?>
					<div class="header-feature">
						<span><?php echo __('News Tab', 'mtcframework');?></span>
						<h2 class="mb0"><?php printf( __( 'Tag : %s', 'mtcframework' ), '' . single_tag_title( '', false ) . '' ); ?></h2>
					</div>
						
					<?php if ( have_posts() ) : ?>
						<div class="main-content">
						<?php while ( have_posts() ) : the_post(); ?>
							<?php get_template_part( 'content', get_post_format() ); ?>
						<?php endwhile; ?>
						</div><div class="spacer"></div>
					<?php else : ?>
						<?php  get_template_part( 'content', 'none' ); ?>
					<?php endif; ?>
					
					
					<?php do_action('after_main_content'); ?>
				</div><!-- end main -->				
				<?php get_template_part('sidebar');?>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>