<?php 
/*
	Template name: Home Shop
*/

global $smof_data;
get_header(); ?>
<div class="wrapper _full_shop_slider">
	<div class="container">
		<div class="row-fluid">
			<div class="span12">
				<div class="full_shop_slider">
					<?php 
					if ( class_exists( 'WooCommerce' ) ) { 
						$count_cat = (isset($smof_data['woocommerce_home_count_category'])) ? $smof_data['woocommerce_home_count_category'] : 8 ;
						echo do_shortcode('[product_categories number="'.$count_cat.'"]'); 
					}
					?>
				</div>
			</div>
		</div>
	</div>
</div>
				
				
<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">		
				<div class="main-full-width">
					<?php if ( class_exists( 'WooCommerce' ) ) { ?>
					<?php get_template_part('slider-shop');?>
					<div class="post_row pt40">
						<div class="header-feature mb40">
							<div id="nav-slider-latest-product" class="posts-controls slider-nav">
							</div>
							<span><?php echo __('Latest Product', 'mtcframework');?></span>
							<h2 class="mb0">Featured Product</h2>
						</div>
					<?php 
						$count_lates = (isset($smof_data['woocommerce_home_count_latest_produk'])) ? $smof_data['woocommerce_home_count_latest_produk'] : 8 ;
						echo do_shortcode('[recent_products per_page="'.$count_lates.'" columns="4" orderby="date" order="desc"]');
					?>
					</div>
					<?php } ?>
				</div><!-- end main-full-width -->		
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>