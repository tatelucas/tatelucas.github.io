<article <?php post_class(); ?>>
	<?php if('gallery' == get_post_format()) { ?>
		<div id="post-slide-<?php the_ID(); ?>" class="carousel slide">
	<?php 
		$gallery = get_post_galleries( $post ,false);
		if($gallery){
			$image_list = '<div class="carousel-inner">';
			
			$galle = explode(',',$gallery[0]['ids']);
			$i=0;
			foreach($galle as $dd){
				$image_list .= '<div class="item';
				$image_list .= ($i==0) ? ' active' :'';
				
				
				$get_images = 'slider-thumb';
				
				
				$image_list .= '">'.wp_get_attachment_image( $dd,$get_images  ).'</div>';
			
				$i++;
			}
			
			$image_list .= '</div>';
			echo $image_list;
		}
	
	?>
		<a class="left carousel-control" href="#post-slide-<?php the_ID(); ?>" data-slide="prev"><i class="icon-chevron-left"></i></a>
		<a class="right carousel-control" href="#post-slide-<?php the_ID(); ?>" data-slide="next"><i class="icon-chevron-right"></i></a>
		</div>
		<?php list_post_single_tag(); ?>
	<?php }	else if('audio' == get_post_format()) { ?>
		<?php 
			$embed_code 	= rwmb_meta( 'mtc_embed_code', 'type=text' );  
			if(empty($embed_code)){
				$content = get_the_content('',true) ;
				$content = apply_filters( 'the_content', $content );
				$content = str_replace( ']]>', ']]&gt;', $content );
				$media = get_media_embedded_in_content($content,'iframe');
				if(!empty($media)){
					$pc = explode('</iframe>',$media[0]);
					$embed_code = $pc[0].'</iframe>';
				}
			} 
		
		?>
		<div class="post-media media-audio">
			<?php echo $embed_code; ?>
		</div>
	<?php }	else if('video' == get_post_format()) { ?>
		<?php 
			$embed_code 	= rwmb_meta( 'mtc_embed_code', 'type=text' );  
			if(empty($embed_code)){
				$content = get_the_content('',true) ;
				$content = apply_filters( 'the_content', $content );
				$content = str_replace( ']]>', ']]&gt;', $content );
				$media = get_media_embedded_in_content($content,'iframe');
				if(!empty($media)){
					$pc = explode('</iframe>',$media[0]);
					$embed_code = $pc[0].'</iframe>';
				}
			} 
		
		?>
		<div class="post-media media-video">
			<?php echo $embed_code; ?>
		</div>
	<?php } else { ?>
		<div class="thumb">
			<?php if ( has_post_thumbnail() ) { ?>
				<?php the_post_thumbnail('medium'); ?>
			<?php } else{ ?>
					<img src="<?php echo get_template_directory_uri().'/img/default-medium.jpg'; ?>" alt="<?php the_title( ); ?>">
			<?php } ?>
			<div class="overlay">
				<div class="overlay">
					<a href="#" class="link"><?php echo __('Read More','mtcfreamwork'); ?></a>
				</div>
			</div>
		</div>
		<?php list_post_single_tag(); ?>
	<?php } ?>
	<div class="list-content">
		<?php the_title('<h2 class="link-2"><a href="'. get_permalink() .'">','</a></h2>'); ?>
		<?php list_post_meta2(); ?>
		<p><?php echo excerpt(26);?></p>
	</div>
</article>