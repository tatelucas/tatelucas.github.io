<?php 
/*
	Template name: Category
*/
get_header(); ?>

<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">
				<div class="main">
					<?php while (have_posts()) : the_post(); ?> 
					<?php 
						the_title(
							'<div class="header-feature"><span>'. __('Categories List','mtcframework') .'</span><h2 class="mb0">',
							'</h2></div>'
						);  ?>					
						<div class="box_list_post">		
							<?php the_content();?>
							<ul class="list_category">
							<?php
							$args=array(
							  'orderby' => 'name',
							  'order' => 'ASC'
							  );
							$categories=get_categories($args);
							  foreach($categories as $category) { 
								echo '<li class="link-2"><a href="' . get_category_link( $category->term_id ) . '" title="' . sprintf( __( "View all posts in %s",'mtcframework'), $category->name ) . '" ' . '> <i class="icon-bookmark-empty"></i> ' . $category->name.'</a></li> ';
								
								
								  } 
							?>
							</ul>
						</div>
					<?php endwhile; ?>
				</div><!-- end main -->				
	
				<?php get_template_part('sidebar');?>
					
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>
