<?php 
/*
	Template name: Authors List
*/

global $smof_data;
get_header(); ?>
<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">
				<div class="main">
					<?php do_action('before_main_content'); ?>
					<div class="main-content box-author-list">
					<h2 class="header-feature-1 text-center"><?php echo  $smof_data['author_page_list_title']; ?></h2>
					<?php 
						
						$user_fields 	= array( 'ID', 'user_login', 'user_nicename', 'user_email', 'user_url' );
						$number     	= $smof_data['number_author_list'];  
						$paged      	= (get_query_var('paged')) ? get_query_var('paged') : 1;  
						$offset     	= ($paged - 1) * $number; 
						
						/* get user list */
						$args_list_user = array(
							'blog_id'      => $GLOBALS['blog_id'],
							'role'         => '',
							'meta_key'     => '',
							'meta_value'   => '',
							'meta_compare' => '',
							'meta_query'   => array(),
							'include'      => array(),
							'exclude'      => array(),
							'orderby'      => 'login',
							'order'        => 'ASC',
							'offset'       => $offset,
							'search'       => '',
							'number'       => $number,
							'count_total'  => false,
							'fields'       => $user_fields,
							'who'          => 'authors'
							);
							
						
						$blogusers = get_users( $args_list_user );
						
						/* Args to get all user */
						$args_all_user = $args_list_user; 
						unset($args_all_user['number']);
						unset($args_all_user['offset']);
						$query_all   = get_users($args_all_user); 

						
						$total_users = count($query_all);  
						$total_query = count($blogusers);  
						$total_pages = intval($total_users / $number) + 1;  
						
					?>
					<ul id="author-list" class="author-list author-list-3">
						<?php mtc_author_list_item($blogusers); ?>
					</ul><div class="spacer"></div>
					<?php  
						
						/* Show Pagination of the list author */
						if ($total_users > $total_query) {  
							echo '<div id="pagination" class="pagination">';
							$current_page = max(1, get_query_var('paged'));  
							echo paginate_links(array(  
								'base' => get_pagenum_link(1) . '%_%',  
								'format' => 'page/%#%/',  
								'current' => $current_page,  
								'total' => $total_pages,  
								'prev_next'    => false,  
								'type'         => 'list',  
								));  
							echo '</div>';  
						}
						?>  
					</div>
					<?php do_action('after_main_content'); ?>
				</div><!-- end main -->				
	
				<?php get_template_part('sidebar');?>
					
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>