<!-- SIDEBAR -->
<div class="sidebar" itemtype="http://schema.org/WPSideBar" itemscope="itemscope">
	<?php if ( is_active_sidebar( 'widget_sidebar' ) ) : ?>
		<?php dynamic_sidebar( 'widget_sidebar' ); ?>
	<?php endif; ?>
</div><!-- END SIDEBAR --><div class="spacer"></div>