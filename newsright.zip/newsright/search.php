<?php get_header(); ?>

<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">
				<div class="main">
				
					<?php do_action('before_main_content'); ?>
					
					<?php if ( have_posts() ) : ?>
						<div class="header-feature">
							<span><?php echo __('Search page', 'mtcframework');?></span>
							<h2 class="mb0"><?php echo __('Search Results For : ', 'mtcframework') . get_search_query(); ?></h2>
						</div>
						
						<div class="main-content">
						<?php while ( have_posts() ) : the_post(); ?>
							<?php get_template_part( 'content'); ?>
						<?php endwhile; ?>
						</div><div class="spacer"></div>
					<?php else : ?>
						<?php  get_template_part( 'content', 'none' ); ?>
						
					<?php endif; ?>
					
					<?php do_action('after_main_content'); ?>
				</div><!-- end main -->				
				
				<?php get_template_part('sidebar');?>
					
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>