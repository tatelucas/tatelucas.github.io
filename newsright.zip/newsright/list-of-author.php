<?php  

global $smof_data;


?><div class="container">
	<div class="row-fluid">
		<div class="span12 content box-author-list">
			<?php 
			
				if(!empty($smof_data['random_author_title'])){
					echo '<h2 class="header-feature-1 text-center">' . $smof_data['random_author_title'] . '</h2>';
				}
				
				
				if(!empty($smof_data['random_author_description'])){
					echo '<p class="description-feature-1 text-center">' . $smof_data['random_author_description'] . '</p>';
				}
			 
			 
				/* get user list */
				$user_fields 	= array( 'ID', 'user_login', 'user_nicename', 'user_email', 'user_url' );
						
				$args_list_user = array(
					'blog_id'      => $GLOBALS['blog_id'],
					'role'         => '',
					'meta_key'     => '',
					'meta_value'   => '',
					'meta_compare' => '',
					'meta_query'   => array(),
					'include'      => array(),
					'exclude'      => array(),
					'orderby'      => 'login',
					'order'        => 'ASC',
					'offset'       => '',
					'search'       => '',
					'number'       => '4',
					'count_total'  => false,
					'fields'       => $user_fields ,
					'who'          => 'authors');
					
				$blogusers = get_users( $args_list_user ); 
				?>
			<ul id="author-list" class="author-list author-list-4">
				<?php mtc_author_list_item($blogusers); ?>
			</ul>
			<div class="clearfix"></div>
		</div>
	</div>
</div>