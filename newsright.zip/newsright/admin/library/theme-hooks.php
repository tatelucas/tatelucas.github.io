<?php 




/* Main Content */
/* add_action('before_main_content','the_breadcrumb',10); */


	add_action('after_main_content','pagination',10);


	//add_action('post-media-slider','mtc_thumbnail_blog_thumb',10);
	//add_action('post-media-slider','post_media_overlay_title',15);

	/* Post */
	add_action('post-media','mtc_thumbnail_blog_thumb',10);
	add_action('post-media','post_media_overlay_title',15);

	add_action('post-content','mtc_post_meta',10);
	add_action('post-content','the_excerpt',15);



/* Single Post */
	add_action('single_before_content','mtc_relate_post',10);
	
	
	add_action('single_after_content','mtc_wp_link_pages',10);
	add_action('single_after_content','mtc_show_review',15);
	add_action('single_after_content','mtc_single_post_tags',20);
	add_action('single_after_content','single_author_info',25);

/* add_action('list_post_content_before_title','list_post_meta',10); */

/* News Box MTC List */
	// big list
	
	add_action('news_boxs_list_before_content','mtc_thumbnail_blog_thumb',10);
	add_action('news_boxs_list_before_content','list_post_single_tag',15);
	
	add_action('news_boxs_list_after_title','list_post_meta2',10);
	add_action('news_boxs_list_after_title','the_excerpt_25',10);
	
	// mini list
	add_action('news_boxs_list_mini_after_title','list_post_meta2',10);
	

/* News Box MTC Block */
	// big list
	add_action('news_boxs_block_before_content','mtc_thumbnail_blog_thumb',10);
	add_action('news_boxs_block_before_content','list_post_single_tag',15);
	
	
	
	add_action('news_boxs_block_after_title','list_post_meta2',10);
	add_action('news_boxs_block_after_title','the_excerpt_25',10);
	
	
	
/* News Box | News Tab Content */	
	add_action('news_tab_list_after_title','list_post_meta2',10);
	add_action('news_tab_list_after_title','the_excerpt_15',15);
	add_action('news_tab_list_after_title','list_post_single_tag',20);
	
	

/* Hooks Library */
	/* Relate Post */
	add_action('mtc_relate_post_after_title','list_post_meta2',10);

	
/* Hooks Widget */

	/* Recent Post */
	/* newsright\admin\library\widget\widget_recent_post.php */
	add_action('mtc_recent_post_after_title','list_post_meta2',10);
	
	/* Popular Post */
	add_action('mtc_popular_post_after_title','list_post_meta2',10);
	

	
	
	
	
	
	
	