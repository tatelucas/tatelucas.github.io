<?php 

/* = News Box V1
**************************************************************/
if(!function_exists('mtc_news_boxs')){
	function mtc_news_boxs() { 
		global $smof_data;
		
		/* news box 1 */
		if($smof_data['switch_news_box1']){
			$args 	= $smof_data['news_box_1'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 2 */
		if($smof_data['switch_news_box2']){
			$args 	= $smof_data['news_box_2'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 3 */
		if($smof_data['switch_news_box3']){
			$args 	= $smof_data['news_box_3'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 4 */
		if($smof_data['switch_news_box4']){
			$args 	= $smof_data['news_box_4'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 5 */
		if($smof_data['switch_news_box5']){
			$args 	= $smof_data['news_box_5'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 6 */
		if($smof_data['switch_news_box6']){
			$args 	= $smof_data['news_box_6'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func	= 'mtc_news_boxs_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 7 */
		if($smof_data['switch_news_box7']){
			$args 	= $smof_data['news_box_7'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 8 */
		if($smof_data['switch_news_box8']){
			$args 	= $smof_data['news_box_8'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}	
	} 
}

/* 
	Part of News Box V1
	News Box 1  List Style
*/
if(!function_exists('mtc_news_boxs_list')){
function mtc_news_boxs_list($args) { 
	/* set data cate */
	$data_cat = $args['list'];
	$limit =2;
	foreach($data_cat as $key_cat=>$cat){
		if(0<$limit ){
			if($cat=='none'){
				unset($data_cat[$key_cat]);
			}else{
				$limit--;
			}
		}else{
			unset($data_cat[$key_cat]);
		}
	}
	if(!empty($data_cat)){ ?>
		<div class="post_row clearfix block_news ">
		<div class="row-fluid">
		<?php 
		
		$count_box = count($data_cat);
		$iterasi = 0;
		foreach($data_cat as $cat){ ?>
			<div class="span6">
				
				<div class="header-feature">
					<span><?php echo __('By Category', 'mtcframework');?></span>
					<h2 class="mb0"><?php echo get_cat_name( $cat ); ?></h2>
				</div>
				
				<?php 
				
				$num_box 	= 1;
				
				query_posts(array('showposts' => 4, 'cat' => $cat ));
				while (have_posts()) : the_post(); 
					
					if(1 == $num_box){ ?>
						<div class="list_home">
						
							<?php do_action('news_boxs_list_before_content'); ?>
							
							<div class="list_home_content">
								<?php do_action('news_boxs_list_before_title'); ?>
								<h2 class="link-2"><a href="<?php echo get_permalink(); ?>"><?php the_title( ); ?></a></h2>
								<?php do_action('news_boxs_list_after_title'); ?>
							</div>	
							
						</div>
						<ul class="list-mini"><?php  
					} 
					
					
					
					else{  ?>
						<li>
							<div class="item">
							
								<?php do_action('news_boxs_list_mini_before_title'); ?>
								
								<h3 class="link-2"><a href="<?php echo get_permalink(); ?>"><?php the_title( ); ?></a></h3>
								
								<?php do_action('news_boxs_list_mini_after_title'); ?>
							</div>
							
						</li><?php 
					} 
					
					
					
				
					$num_box ++;
				endwhile;
					
				/* Reset Query */
				wp_reset_query(); ?>
				</ul>
			</div> <?php
			
			
			$count_box--; 
			
			if($iterasi==1){
				$iterasi = 0;
				if(1<=$count_box){
					echo '</div><div class="row-fluid">'; }
				
			} else{
				$iterasi++;
			}
		} 
		
		?>
		</div>
		</div><?php 
	}
	
} /* end mtc_news_boxs_list() */
}
	
/* 
	Part of News Box V1
	News Box 1  Block Style	
*/
if(!function_exists('mtc_news_boxs_block')){
function mtc_news_boxs_block($args){
	/* set data cate */
	$data_cat = $args['block'];
	
	foreach($data_cat as $key_cat=>$cat){
		if($cat=='none'){
			unset($data_cat[$key_cat]);
		}
	}
	
	
	if(!empty($data_cat)){	
		foreach($data_cat as $key_cat=>$cat_id){ ?>
		<div class="post_row clearfix">
			<div class="header-feature">
				<span><?php echo __('By Category', 'mtcframework');?></span>
				<h2 class="mb0"><?php echo get_cat_name( $cat_id ); ?></h2>
			</div>
			<div class="box_list news_block">
				<?php 
				$no = 1;
				$list_more = '';
				global $post;
				query_posts(array('showposts' => 6, 'cat' => $cat_id ));
				while (have_posts()) : the_post();
					if($no==1) { ?> 	
					<div class="list_home mr0">
					
						<?php do_action('news_boxs_block_before_content'); ?>
						
						<div class="list_home_content">
							<?php do_action('news_boxs_block_before_title'); ?>
							
							<h2 class="link-2"><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h2>
							
							<?php do_action('news_boxs_block_after_title'); ?>
						</div>	
					</div>
					<?php 
					} else{
						$list_more .='<li>';
							$list_more .='<div class="item">';
								$list_more .='<div class="newsImg pull-left">'. get_the_post_thumbnail($post->ID,'thumbnail') .'</div>';
							
								$list_more .='<h3 class="link-2"><a href="'.get_permalink().'">'.get_the_title().'</a></h3>';
								$list_more .='<div class="meta">';
									$list_more .= __( 'by ', 'mtcframework' );
									$list_more .= '<a href="'. get_author_posts_url( get_the_author_meta( 'ID' ) ) .'">' . get_the_author_meta('display_name') . '</a> - ';
									$list_more .= '<a href="'.get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')).'">'.get_the_time(get_option('date_format')).'</a>';
								$list_more .='</div>';
							
							$list_more .='</div>';
						$list_more .='</li>';
					}
					$no++;
				endwhile;
				wp_reset_query(); ?>
				<div class="news_block_more">
				<ul class="list-mini">
					<?php echo $list_more; ?>
					
				</ul>
				</div>
			</div>
		</div>
		<?php
		} 
	}
}  
/* END mtc_news_boxs_block() */
}












/* = News Box V3
**************************************************************/
if(!function_exists('mtc_news_boxs_v3')){
	function mtc_news_boxs_v3() { 
		global $smof_data;
		
		/* news box 1 */
		if($smof_data['switch_news_box1']){
			$args 	= $smof_data['news_box_1'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			
			$func 	= 'mtc_news_boxs_v3_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 2 */
		if($smof_data['switch_news_box2']){
			$args 	= $smof_data['news_box_2'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_v3_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 3 */
		if($smof_data['switch_news_box3']){
			$args 	= $smof_data['news_box_3'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_v3_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 4 */
		if($smof_data['switch_news_box4']){
			$args 	= $smof_data['news_box_4'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_v3_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 5 */
		if($smof_data['switch_news_box5']){
			$args 	= $smof_data['news_box_5'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_v3_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 6 */
		if($smof_data['switch_news_box6']){
			$args 	= $smof_data['news_box_6'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func	= 'mtc_news_boxs_v3_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 7 */
		if($smof_data['switch_news_box7']){
			$args 	= $smof_data['news_box_7'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_v3_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}
		
		/* news box 8 */
		if($smof_data['switch_news_box8']){
			$args 	= $smof_data['news_box_8'];
			$style 	= (isset($args['op'])) ? $args['op'] : 'list';
			$func 	= 'mtc_news_boxs_v3_'.$style;
			
			if(function_exists($func)){
				call_user_func($func, $args); }
		}	
	} 
}

/* 
	Part of News Box V3
	News Box 3  Block Style	
*/
if(!function_exists('mtc_news_boxs_v3_list')){
function mtc_news_boxs_v3_list($args) { 
	/* set data cate */
	$data_cat = $args['list'];
	foreach($data_cat as $key_cat=>$cat){
		if($cat=='none'){
			unset($data_cat[$key_cat]);
		}
	}


	if(!empty($data_cat)){ ?>
		<div class="post_row clearfix block_news ">
		<div class="row-fluid">
		<?php 
		
		$count_box = count($data_cat);
		$iterasi = 0;
		foreach($data_cat as $cat){ ?>
			<div class="span4">
				
				<div class="header-feature">
					<span><?php echo __('By Category', 'mtcframework');?></span>
					<h2 class="mb0"><?php echo get_cat_name( $cat ); ?></h2>
				</div>
				
				<?php 
				
				$num_box 	= 1;
				
				query_posts(array('showposts' => 4, 'cat' => $cat ));
				while (have_posts()) : the_post(); 
					
					if(1 == $num_box){ ?>
						<div class="list_home">
						
							<?php do_action('news_boxs_list_before_content'); ?>
							
							<div class="list_home_content">
								<?php do_action('news_boxs_list_before_title'); ?>
								<h2 class="link-2"><a href="<?php echo get_permalink(); ?>"><?php the_title( ); ?></a></h2>
								<?php do_action('news_boxs_list_after_title'); ?>
							</div>	
							
						</div>
						<ul class="list-mini"><?php  
					} 
					
					
					
					else{  ?>
						<li>
							<div class="item">
							
								<?php do_action('news_boxs_list_mini_before_title'); ?>
								
								<h3 class="link-2"><a href="<?php echo get_permalink(); ?>"><?php the_title( ); ?></a></h3>
								
								<?php do_action('news_boxs_list_mini_after_title'); ?>
							</div>
							
						</li><?php 
					} 
					$num_box ++;
				endwhile;
					
				/* Reset Query */
				wp_reset_query(); ?>
				</ul>
			</div> <?php
			
			
			$count_box--; 
			
			if($iterasi==2){
				$iterasi = 0;
				if(1<=$count_box){
					echo '</div><div class="row-fluid">'; }
			} else{
				$iterasi++;
			}
		} 
		
		?>
		</div>
		</div><?php 
	}
	
	
	

	
	/* if(!empty($data_cat)){ 
		$count_box = count($data_cat);
		$iterasi = 0;
		foreach($data_cat as $cat){
	?>
	
	<h2 class="ribbon-v3"><span><?php echo get_cat_name( $cat ); ?></span></h2>
	<section id="latest-1">
	<?php
	query_posts(array('showposts' => 5, 'cat' => $cat ));
	while (have_posts()) : the_post();  ?> 	
		<article class="list-v1">
		<div class="thumb-v1">
			<?php if ( has_post_thumbnail() ) { ?>
				<?php the_post_thumbnail('blog-small'); ?>
			<?php } else{ ?>
				<img  class="respon" src="<?php echo get_template_directory_uri().'/img/default_thumbnail_large.jpg'; ?>" alt="<?php the_title( ); ?>">
			<?php } ?>
		</div>
		<div class="content-v1">
			<h2><a href="<?php echo get_permalink(); ?>"><?php the_title( ); ?></a></h2>
			<div class="panel-v">
				<ul>
					<li><a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php the_time(get_option('date_format')); ?></a></li>
					<li class="link-author"><?php the_author_posts_link(); ?></li>
					<?php echo get_mtc_rating_sys('span','<li>','</li>'); ?>
				</ul>	
			</div>
			
			<p><?php echo excerpt(25);?></p>
		</div>
		</article>
		
		<?php 
	endwhile;
	wp_reset_query();
	?>
	</section>
	
	
	<?php }
	
	} */
}
}

/* 
	Part of News Box V3
	News Box 3  Block Style	
*/
if(!function_exists('mtc_news_boxs_v3_block')){
function mtc_news_boxs_v3_block($args){
	/* set data cate */
	$data_cat = $args['block'];
	
	foreach($data_cat as $key_cat=>$cat){
		if($cat=='none'){
			unset($data_cat[$key_cat]);
		}
	}
	if(!empty($data_cat)){	
		foreach($data_cat as $key_cat=>$cat_id){ ?>
		<div class="header-feature">
			<span><?php echo __('By Category', 'mtcframework');?></span>
			<h2 class="mb0"><?php echo get_cat_name( $cat_id ); ?></h2>
		</div>
				
		<section id="latest-3">
			<div class="box-list-v3">
			<?php 
			$no = 1;
			$list_more = '';
			global $post;
			query_posts(array('showposts' => 6, 'cat' => $cat_id ));
			while (have_posts()) : the_post();
				if($no==1) { ?> 	
					<div class="list-v3-large news-60">
						<?php if ( has_post_thumbnail() ) { ?>
							<?php the_post_thumbnail('large'); ?>
						<?php } else{ ?>
							<img src="<?php echo get_template_directory_uri().'/img/default_thumbnail_large.jpg'; ?>" alt="<?php the_title( ); ?>">
						<?php } ?>

						<?php post_media_overlay_title2(); ?>
	
					</div>
				<?php 
				} else{
						$list_more .='<article class="list-v3-small">
							<div class="thumb-v3">
								'. get_the_post_thumbnail($post->ID,'thumbnail') .'
							</div>
							<h3 class="link-2"><a href="'.get_permalink().'">'.get_the_title().'</a></h3>';
							$list_more .='<div class="meta">';
									$list_more .= __( 'by ', 'mtcframework' );
									$list_more .= '<a href="'. get_author_posts_url( get_the_author_meta( 'ID' ) ) .'">' . get_the_author_meta('display_name') . '</a> - ';
									$list_more .= '<a href="'.get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')).'">'.get_the_time(get_option('date_format')).'</a>';
								$list_more .='</div>';
						$list_more .='</article>';
							
							
					
				}
				$no++;
			endwhile;
			wp_reset_query(); ?>
			<div class="box-list-v3-small news-40">
				<?php echo $list_more; ?><div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
			</div>
		</section>
		
		<?php
		} 
	}
}  
/* END mtc_news_boxs_block() */
}




