<?php 




/* = Handle Tabs News
***************************************************************************/
add_action( 'wp_ajax_nopriv_mtc-news-pict', 'mtc_handle_news_pict' );
add_action( 'wp_ajax_mtc-news-pict', 'mtc_handle_news_pict' );



if(!function_exists('mtc_handle_news_pict')){
	function mtc_handle_news_pict(){ 
		global $smof_data;
		$args = array(
			'posts_per_page' 		=> $smof_data['news_in_picture_count'],
			'orderby' 				=> 'post_date',
			'ignore_sticky_posts' 	=> 1,
			'order' 				=> 'DESC' );
			
		$cat = $_POST['cat'];
		
		if(!empty($cat) && 'all' != $cat){
			$args['cat'] = $cat;
		}

		query_posts($args);
		while (have_posts()) : the_post();
			news_in_picture_content();
		endwhile; 
		wp_reset_query(); 
	}
}







if(!function_exists('mtc_news_in_picture')){
	function mtc_news_in_picture(){ 
		global $smof_data;
		if($smof_data['switch_news_in_picture']){ ?>
			<div class="post_row mt10">
				
				<div class="header-feature">
					<span><?php echo __('Pictures Tab', 'mtcframework');?></span>
					<h2 class="mb0"><?php echo $smof_data['news_in_picture_title']; ?></h2>
				</div>
				
				<div class="tab-controls">
					<ul>
					<?php 
					$data_cat = array(
						$smof_data['news_pict_cat1'],
						$smof_data['news_pict_cat2'],
						$smof_data['news_pict_cat3'],
						$smof_data['news_pict_cat4'],
						$smof_data['news_pict_cat5'],
						$smof_data['news_pict_cat6'],
						$smof_data['news_pict_cat7'],
						$smof_data['news_pict_cat8']
					);
			
					foreach($data_cat as $key_cat=>$cat){
						if($cat=='none'){
							unset($data_cat[$key_cat]);
						}
					}
			
					
					
					
					$iterasi = 1;
					$tab_id = 'tab-content'.rand(99,990).time();
					$cat_pertama = 0;
					
					
					$tab_nav ='<li class="active"><a href="javascript:;"
					data-action="mtc-news-pict"			
					data-target="'.$tab_id.'"
					data-count="6" 
					data-cat="all"
					>'. __('All','mtcframework') .'</a></li>';
					
					foreach($data_cat as $cat){
						/* $tab_nav .='<li '.(($iterasi==1) ? 'class="active"' : '' ).'> */
						$tab_nav .='<li>
						
						<a href="javascript:;" 
						data-action="mtc-news-pict"
						data-target="'.$tab_id.'"
						data-cat="' .$cat. '"
						>' .get_cat_name( $cat ). '</a></li>';
						if(1==$iterasi) { $cat_pertama =  $cat; } 
						$iterasi++; 
					}
						
					echo $tab_nav; 
					?>
					</ul><!-- End Tab Nav -->
				</div>
			
			
				<div class="content-news-pictures" id="<?php echo $tab_id; ?>">
					<?php 
					
					$args = array(
						'posts_per_page' 		=> $smof_data['news_in_picture_count'],
						'orderby' 				=> 'post_date',
						'ignore_sticky_posts' 	=> 1,
						'order' 				=> 'DESC' );
					
					query_posts($args);
					while (have_posts()) : the_post();
						news_in_picture_content();
					endwhile; 
					wp_reset_query();
					?>
				</div>
				<div class="clearfix"></div>
			</div><?php
		} 
	} 

} 

function news_in_picture_content(){ ?>
	<div class="list_mini news-pict">
		<a class="thumb" href="<?php echo get_permalink(); ?>" >
		<?php if ( has_post_thumbnail() ) { ?>
			<?php the_post_thumbnail('medium-square'); ?>
		<?php } else{ ?>
			<img src="<?php echo get_template_directory_uri().'/img/default-medium-square.jpg'; ?>" alt="<?php the_title(); ?>">
		<?php } ?>
		</a>
		<h3 class="pict-title link-2">
			<a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a>
		</h3>
	</div>
<?php }


/* 
if(!function_exists('mtc_news_in_picture_v3')){
	function mtc_news_in_picture_v3(){ 
	global $smof_data;
	if($smof_data['switch_news_in_picture']){ 
	?>
		<h2 class="ribbon-v3 mb0"><span>latest Pictures</span></h2>
		<div class="post_row row-pict-v3">
			<?php 
			$args = array(
						'posts_per_page' 		=> $smof_data['news_in_picture_count'],
						'orderby' 				=> 'post_date',
						'ignore_sticky_posts' 	=> 1,
						'order' 				=> 'DESC' );
			$content = $smof_data['news_in_picture_content'];
					
			if('latest' == $content['content']){
			
			}
			else if('category' == $content['content']){
				$args['cat'] = $content['category'];
			}
			
			else if('tag' == $content['content']){
				$args['tag'] = $content['tag'];
			}
					
			wp_reset_query(); 		
			query_posts($args);
			
			
			?>
			<section id="latest-picture" class="">
				<?php while (have_posts()) : the_post(); ?>
				<div class="news-pict-v3">
					<a class="thumb" href="<?php echo get_permalink(); ?>" data-toggle="tooltip" data-original-title="<?php the_title(); ?>" title="<?php the_title(); ?>">
					<?php if ( has_post_thumbnail() ) { ?>
						<?php the_post_thumbnail('medium-square'); ?>
					<?php } else{ ?>
						<img src="<?php echo get_template_directory_uri().'/img/thumb_150.jpg'; ?>" alt="<?php the_title( ); ?>">
					<?php } ?>
					</a>
				</div>
				<?php endwhile; wp_reset_query(); ?>
			</section>
			<div class="clearfix"></div>
		</div>
	
	<?php 
	}
	}
} */


