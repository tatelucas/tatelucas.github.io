<?php
/* 
	5:27 PM 7/8/2013
*/
class mtc_tabpost_widget extends WP_Widget {

    function mtc_tabpost_widget() {
		# Constructor
		$widget_ops = array( 'classname' => 'widget_mtc_tabpost_widget', 'description' => __( 'Widget for Show Post in Tab.','mtcframework' ) );
		$this->WP_Widget( 'mtc-tabpost-widget', __( 'MTC : Post Tab','mtcframework' ), $widget_ops );
	} 	# end of function mtc_tabpost_widget()
    

    function widget($args, $instance) {
		// prints the widget
		extract( $args, EXTR_SKIP );
	

		$show_popular 	= (!empty($instance['popular'])) 	? esc_attr($instance['popular']) 	: 4 ;
		$show_recent 	= (!empty($instance['recent'])) 	? esc_attr($instance['recent']) 	: 4 ;
		$title 			= (!empty($instance['title'])) 		? esc_attr($instance['title']) 		: '' ; 
		$title 			= apply_filters( 'widget_title', $instance['title'] );
		$unik_kode_widget = rand(0,999);
	
		echo $before_widget;
		if ( ! empty( $title ) )
			echo $before_title . $title . $after_title;
		?>

		<ul class="tabs tabs_<?php echo $unik_kode_widget;?>">
			<li class="link-2 active"><a class="popular" href="#tab1_<?php echo $unik_kode_widget;?>">Popular</a></li>
			<li class="link-2"><a class="recent" href="#tab2_<?php echo $unik_kode_widget;?>">Recent</a></li>
			<li class="link-2"><a class="archives" href="#tab3_<?php echo $unik_kode_widget;?>">Archives</a></li>
		</ul><div class="spacer"></div>
		
		<div class="tab_container">
			<div id="tab1_<?php echo $unik_kode_widget;?>" class="tab_content tab_content_<?php echo $unik_kode_widget;?>">
				<ul class="post-list">
				<?php
					$args=array(
					  'orderby'=>'comment_count',
					  'order'=>'DESC',
					  'post_type' => 'post',
					  'post_status' => 'publish',
					  'posts_per_page' => $show_popular,
					  'ignore_sticky_posts' => 1
					);
					
					$my_query = null;
					$my_query = new WP_Query($args);
					if( $my_query->have_posts() ) : 
					while ($my_query->have_posts()) : $my_query->the_post();  ?>
					<li>
						<div class="thumb">
							<?php if ( has_post_thumbnail() ) { ?>
								<?php the_post_thumbnail('medium'); ?>
							<?php } else{ ?>
								<img src="<?php echo get_template_directory_uri().'/img/default-medium.jpg'; ?>" alt="<?php the_title( ); ?>">
							<?php } ?>
							<div class="overlay">
								<a href="<?php the_permalink(); ?>" class="link">Read More</a>
							</div>
						</div>
						<h3 class="post-title link-2">
							<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a>
						</h3>
						<?php list_post_meta2(); ?>
					</li>	
				<?php  endwhile; endif; wp_reset_query();  ?>					
				</ul>
			</div>
			
			
			
			<div id="tab2_<?php echo $unik_kode_widget;?>" class="tab_content tab_content_<?php echo $unik_kode_widget;?>">
				<ul class="post-list">
				<?php
				/* GET recent_posts */
				$args = array( 'numberposts' => $show_recent );
				$recent_posts = wp_get_recent_posts( $args,OBJECT);
				global $post;
				foreach( $recent_posts as $recent ){ 
					$post = $recent;
					setup_postdata( $post );
				?>
					<li>
						<div class="thumb">
							<?php if ( has_post_thumbnail() ) { ?>
								<?php the_post_thumbnail('medium'); ?>
							<?php } else{ ?>
								<img src="<?php echo get_template_directory_uri().'/img/default-medium.jpg'; ?>" alt="<?php the_title( ); ?>">
							<?php } ?>
							<div class="overlay">
								<a href="<?php the_permalink(); ?>" class="link">Read More</a>
							</div>
						</div>
						<h3 class="post-title link-2">
							<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a>
						</h3>
						<?php list_post_meta2(); ?>
					</li>
				<?php	}  ?>
				<?php	wp_reset_postdata();  ?>
				</ul>
			</div>
				
				
			<div id="tab3_<?php echo $unik_kode_widget;?>" class="tab_content tab_content_<?php echo $unik_kode_widget;?>">
				<ul class="list-archive">
					<?php wp_get_archives( 
						array( 
							'type' 				=> 'monthly', 
							'limit' 			=> 12 ,
							'format'    		=> 'custom', 
							'before'          	=> '<li>',
							'after'           	=> '</li>',
							'show_post_count' 	=> false,
							'echo'            	=> 1,
							'order'           	=> 'DESC') 
					); ?>
				</ul>
			</div>
		</div>
		<div class="spacer"></div><?php 
		
		add_script_mtc_tabpost_widget($unik_kode_widget);
		echo $after_widget;
	
	
    }

	
	
	
    function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] 		= strip_tags($new_instance['title']); 
		$instance['popular'] 	= strip_tags($new_instance['popular']);
		$instance['recent'] 	= strip_tags($new_instance['recent']);
        return $instance;
    }

	
	
	
	
    function form($instance)
	{
		$title 		= (!empty($instance['title'])) 		? esc_attr($instance['title']) : '' ; 
		$popular 	= (!empty($instance['popular'])) 	? esc_attr($instance['popular']) : 4 ;
		$recent 	= (!empty($instance['recent'])) 	? esc_attr($instance['recent']) : 4 ; ?>

		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:','mtcframework'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $title; ?>" type="text">
        </p>
		<p>
			<label for="<?php echo $this->get_field_id('popular'); ?>"><?php _e('Number of popular to show :','mtcframework'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('popular'); ?>" name="<?php echo $this->get_field_name('popular'); ?>" value="<?php echo $popular; ?>"  maxlength="2" type="text">
        </p>
		
		<p>
			<label for="<?php echo $this->get_field_id('recent'); ?>"><?php _e('Number of recent to show :','mtcframework'); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id('recent'); ?>" name="<?php echo $this->get_field_name('recent'); ?>" value="<?php echo $recent; ?>"  maxlength="2" type="text">
        </p><?php
    }
	
	
}

add_action( 'widgets_init', create_function( '', 'return register_widget("mtc_tabpost_widget");' ) );



function add_script_mtc_tabpost_widget($id){ ?><script type="text/javascript">
	jQuery(function () {
		 /* Default Action */
		jQuery(".tab_content_<?php echo $id;?>").hide();
		jQuery("ul.tabs_<?php echo $id;?> li:first").addClass("active").show(); 
		jQuery(".tab_content_<?php echo $id;?>:first").show(); 
		/* On Click Event */
		jQuery("ul.tabs_<?php echo $id;?> li").click(function() {
			jQuery("ul.tabs_<?php echo $id;?> li").removeClass("active"); 
			jQuery(this).addClass("active"); 
			jQuery(".tab_content_<?php echo $id;?>").hide(); 
			var activeTab = jQuery(this).find("a").attr("href"); 
			jQuery(activeTab).fadeIn(); 
			return false;
		}); 
    });
</script><?php  }
