<?php
/* 
	5:27 PM 7/8/2013
*/ 
class mtc_socmed_widget extends WP_Widget {

    function mtc_socmed_widget() {
		# Constructor
		$widget_ops = array( 'classname' => 'mtc_socmed_widget', 'description' => __( 'Widget for Show Social Media.' ,'mtcframework') );
		$this->WP_Widget( 'mtc-social-media-widget', __( 'MTC : Social Media' ,'mtcframework'), $widget_ops );
	} 	# end of function mtc_socmed_widget()
    

    function widget($args, $instance) {
		global $smof_data;
		
		// prints the widget
		extract( $args, EXTR_SKIP );
		
		$title 	= esc_attr($instance['title']);
		$title = apply_filters('widget_title', empty( $instance['title'] ) ? __( 'Social Media' ,'mtcframework') : $instance['title'], $instance, $this->id_base);	
		echo $before_widget;
		
		if ( isset($title) && !empty($title) ) echo $before_title . $title . $after_title; 
			
		echo mtc_social_media();

		echo $after_widget;
    }

	
	
	
    function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] 	= strip_tags($new_instance['title']);
        return $instance; 

    }

    function form($instance) {
		
		$title 	= (!empty($instance['title'])) ? esc_attr($instance['title']) : 'Social Media' ;
        ?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title :','mtcframework'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $title; ?>"   type="text">
        </p>
		<?php 
    }
}

add_action( 'widgets_init', create_function( '', 'return register_widget("mtc_socmed_widget");' ) );

