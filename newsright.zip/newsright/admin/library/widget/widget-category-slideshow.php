<?php 


class mtc_categories_slideshow_widget extends WP_Widget {

	function __construct() {
		$widget_ops = array( 'classname' => 'mtc-categories-slideshow-widget', 'description' => __( "A list or dropdown of categories. and Exclude options" ,'mtcframework') );
		parent::__construct('mtc-categories', __('MTC: Categories Slider','mtcframework'), $widget_ops);
	}

	function widget( $args, $instance ) {
		extract( $args );

		$title = apply_filters('widget_title', empty( $instance['title'] ) ? __( 'Categories' ,'mtcframework') : $instance['title'], $instance, $this->id_base);
		
		$cat = esc_attr($instance['cat'] );
		$count = esc_attr($instance['count'] );

		echo $before_widget;
		if ( $title )
			echo $before_title . $title . $after_title;
			
			
		$the_cat = array();
		
		$in = explode(',',$cat);
		$in = array_filter($in);
		if(!empty($in)){
			$the_cat = $in;
		}
	
		if(!empty($the_cat)){
			foreach($the_cat as $cat_id){ ?>
			
				<div class="box-mtc-csw">
					<h3 class="csw-title"><?php echo get_cat_name( $cat_id ); ?></h3>
					<div class="csw-nav" id="csw-nav-<?php echo $cat_id; ?>"></div>
					<div class="csw-content" id="csw-content-<?php echo $cat_id; ?>">
						<?php query_posts(array('showposts' => $count, 'cat' => $cat_id )); ?>
						<?php while (have_posts()) : the_post();  ?>
							<div class="csw-item">
								<a href="<?php the_permalink();?>" title="<?php the_title(); ?>">
									<?php if ( has_post_thumbnail() ) { ?>
										<?php the_post_thumbnail('thumbnail'); ?>
									<?php } else{ ?>
											<img src="<?php echo get_template_directory_uri().'/img/default-blog-thumb.jpg'; ?>" alt="<?php the_title( ); ?>">
									<?php } ?>
								</a>
							</div>
						
						<?php endwhile; ?>
						<?php wp_reset_query(); ?>
					</div>
				</div>
			<?php }
		}

		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] 	= strip_tags($new_instance['title']);
		$instance['cat'] 	= strip_tags($new_instance['cat']);
		$instance['count'] 	= !empty($new_instance['count']) ? $new_instance['count'] : 4;

		return $instance;
	}

	function form( $instance ) {
		//Defaults
		$instance 	= wp_parse_args( (array) $instance, array( 'title' => '') );
		$title 		= esc_attr( $instance['title'] );
		$cat 		= esc_attr( $instance['cat'] );
		$count 		= esc_attr( $instance['count'] );

?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e( 'Title :' ,'mtcframework'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></p>

		<p><label for="<?php echo $this->get_field_id('cat'); ?>"><?php _e( 'Categories :','mtcframework' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('cat'); ?>" name="<?php echo $this->get_field_name('cat'); ?>" type="text" value="<?php echo $cat; ?>" /><br />
		Categories IDs, separated by commas.
		</p>
		
		<p><label for="<?php echo $this->get_field_id('count'); ?>"><?php _e( 'Post per categories :','mtcframework' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>" type="text" value="<?php echo $count; ?>" />
		
		</p>	
<?php
	}

}
 add_action( 'widgets_init', create_function( '', 'return register_widget("mtc_categories_slideshow_widget");' ) );