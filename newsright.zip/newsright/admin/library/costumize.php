<?php 
/**
 * Add Customizer option
 * @since v1.0
 */
add_action( 'customize_register', 'mtc_theme_customizer' );

function mtc_theme_customizer( $wp_customize ) {
	$wp_customize->get_setting('blogname')->transport='postMessage';
	$wp_customize->get_setting('blogdescription')->transport='postMessage';
	$wp_customize->get_setting('header_textcolor')->transport='postMessage';
	
	
	/* custom_set section */
	$wp_customize->add_section( 'custom_set', array(
		'title' => 'Custom', // The title of section
		'description' => 'Settings main style section', // The description of section
	) );

		// The latter code snippets go here.
		$wp_customize->add_setting( 'custom_set[body]', array(
			/* 'default' => '#FFFFFF', */
			'type' => 'option',
			'transport'      => 'postMessage',
			'capability'     => 'edit_theme_options',
			'sanitize_callback'    => 'sanitize_hex_color_no_hash',
			'sanitize_js_callback' => 'maybe_hash_hex_color',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'custom_set[body]', array(
			'label'   => 'Body Color',
			'section' => 'custom_set',
		) ) ); 
	

	
		$wp_customize->add_setting( 'custom_set[color]', array(
			/* 'default' => '#11AA72', */
			'type' => 'option',
			'transport'      => 'postMessage',
			'capability'     => 'edit_theme_options',
			'sanitize_callback'    => 'sanitize_hex_color_no_hash',
			'sanitize_js_callback' => 'maybe_hash_hex_color',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'custom_set[color]', array(
			'label'   => 'Themes Color',
			'section' => 'custom_set',
		) ) );
	

	
		$wp_customize->add_setting( 'custom_set[color2]', array(
			/* 'default' => '#0b905f', */
			'type' => 'option',
			'transport'      => 'postMessage',
			'capability'     => 'edit_theme_options',
			'sanitize_callback'    => 'sanitize_hex_color_no_hash',
			'sanitize_js_callback' => 'maybe_hash_hex_color',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'custom_set[color2]', array(
			'label'   => 'Themes Color 2',
			'section' => 'custom_set',
		) ) );

		
		
		$wp_customize->add_setting( 'custom_set[color3]', array(
			'type' => 'option',
			'transport'      => 'postMessage',
			'capability'     => 'edit_theme_options',
			'sanitize_callback'    => 'sanitize_hex_color_no_hash',
			'sanitize_js_callback' => 'maybe_hash_hex_color',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'custom_set[color3]', array(
			'label'   => 'Themes Color 3',
			'section' => 'custom_set',
		) ) ); 
	
	
	
	/* add js to footer. to live change */
	if ( $wp_customize->is_preview() && ! is_admin() ) {
			add_action( 'wp_footer', 'mtc_preview', 21);
	}

}




/**
 * Load js ke footer untuk menerima perubahan variable dari custumizer
 * @since v1.0 fix
 */
function mtc_preview(){
?><script type="text/javascript">
wp.customize('custom_set[body]',function( value ) {
			value.bind(function(to) {
				jQuery('body').css('background-color', to ? to : ''  ); 
			});
		});



		
wp.customize('custom_set[color]',function( value ) {
			value.bind(function(to) {
				jQuery('.header_top ul.nav, ._header_top,.btn-danger ,#back-top a,.masonry-1 article.type-post .ribbon-label,.tab_list_content .ribbon-label,.post_row.block_news .list_home .ribbon-label,.more-slider li .ribbon-label,.woocommerce span.onsale, .woocommerce-page span.onsale,.woocommerce nav.woocommerce-pagination ul li span.current,.woocommerce nav.woocommerce-pagination ul li a:hover,.woocommerce nav.woocommerce-pagination ul li a:focus,.woocommerce #content nav.woocommerce-pagination ul li span.current,.woocommerce #content nav.woocommerce-pagination ul li a:hover,.woocommerce #content nav.woocommerce-pagination ul li a:focus,.woocommerce-page nav.woocommerce-pagination ul li span.current,.woocommerce-page nav.woocommerce-pagination ul li a:hover,.woocommerce-page nav.woocommerce-pagination ul li a:focus,.woocommerce-page #content nav.woocommerce-pagination ul li span.current,.woocommerce-page #content nav.woocommerce-pagination ul li a:hover,.woocommerce-page #content nav.woocommerce-pagination ul li a:focus').css('background', to ? to : '' );
			});
			
			value.bind(function(to) {
				jQuery('#bbpress-forums #bbp-search-form input.button,.pagination ul > li > a:hover, .pagination ul > li > a:focus, .pagination ul > .active > a, .pagination ul > .active > span,.pagination ul > .disabled > span,.pagination ul > .disabled > a,.pagination ul > .disabled > a:hover,.pagination ul > .disabled > a:focus').css('background-color', to ? to : '' );
			});
			
			value.bind(function(to) {
				jQuery('div.tab-controls ul li.active,.more-slider .slider-more-header,.pagination ul > li > a, .pagination ul > li > span,h2.widget_title,.more-slider a.prev, .more-slider a.next,.slider-nav a,div.header-feature,h3#comments, h3#reply-title,#content div.product .product_title, .woocommerce div.product .product_title, .woocommerce-page #content div.product .product_title, .woocommerce-page div.product .product_title,.woocommerce nav.woocommerce-pagination ul li a,.woocommerce nav.woocommerce-pagination ul li span,.woocommerce #content nav.woocommerce-pagination ul li a,.woocommerce #content nav.woocommerce-pagination ul li span,.woocommerce-page nav.woocommerce-pagination ul li a,.woocommerce-page nav.woocommerce-pagination ul li span,.woocommerce-page #content nav.woocommerce-pagination ul li a,.woocommerce-page #content nav.woocommerce-pagination ul li span,#bbpress-forums fieldset.bbp-form legend,.box-widget-footer').css('border-color', to ? to : '' );
			});
			value.bind(function(to) {
				jQuery('#bbpress-forums li.bbp-header').css('border-bottom-color', to ? to : '' );
			});
			
			value.bind(function(to) {
				jQuery('nav.footer-navigation li:hover > a,.woocommerce div.product span.price, .woocommerce div.product p.price, .woocommerce #content div.product span.price, .woocommerce #content div.product p.price, .woocommerce-page div.product span.price, .woocommerce-page div.product p.price, .woocommerce-page #content div.product span.price, .woocommerce-page #content div.product p.price,.woocommerce ul.products li.product .price, .woocommerce-page ul.products li.product .price,.slider-nav a,.more-slider a.prev, .more-slider a.next').css('color', to ? to : '' );
			});
			
			
		});
		
wp.customize('custom_set[color2]',function( value ) {
			value.bind(function(to) {
				
				jQuery('body').append('<style>'+
				'nav.main-navigation li:hover > a, ' +
				'nav.main-navigation ul ul :hover > a,' +
				'.widget_footer  div.meta a:hover' +
				'{ color:' + to + '} '+
				'</style>' );
				
				jQuery('body').append('<style>'+
				'.bbp-login-form .bbp-submit-wrapper #user-submit:hover,'+
				'.btn-danger:hover, '+
				'#back-top a:hover, '+
				'.header_top li:hover > a, .header_top ul ul :hover > a,'+
				'.header_top > ul li > ul,'+
				'.header_top ul.nav li.current-menu-item,'+
				'#data-cart p.buttons a.button.checkout:hover,'+
				'.woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce #content input.button.alt:hover, .woocommerce-page a.button.alt:hover, .woocommerce-page button.button.alt:hover, .woocommerce-page input.button.alt:hover, .woocommerce-page #respond input#submit.alt:hover, .woocommerce-page #content input.button.alt:hover' +
				'{ background:' + to + '} '+
				'</style>' );
				
				jQuery('body').append('<style>'+
				'.topnav_toggle,#commentform p.form-submit input[type="submit"]:hover,#bbpress-forums #bbp-search-form input.button:hover'+
				'{ background-color:' + to + '} '+
				'</style>' );
				
				jQuery('body').append('<style>'+
				'nav.main-navigation > ul li > ul'+
				'{ border-top-color:' + to + '} '+
				'</style>' );
				
				jQuery('body').append('<style>'+
				'.slider-nav a:hover,.more-slider a.prev:hover,.more-slider a.next:hover'+
				'{ border-color:' + to + '; background:' + to + '} '+
				'</style>' );
			});	
	});
		
wp.customize('custom_set[color3]',function( value ) {		
		value.bind(function(to) {
			jQuery('body').append('<style>'+
				'.header_top ul ul li a:hover,.topnav_toggle:hover'+
				'{ background-color:' + to + '} '+
				'</style>' );
		});
	});
</script>


	


<?php }




function hex2rgb($hex) {
   $hex = str_replace("#", "", $hex);

   if(strlen($hex) == 3) {
      $r = hexdec(substr($hex,0,1).substr($hex,0,1));
      $g = hexdec(substr($hex,1,1).substr($hex,1,1));
      $b = hexdec(substr($hex,2,1).substr($hex,2,1));
   } else {
      $r = hexdec(substr($hex,0,2));
      $g = hexdec(substr($hex,2,2));
      $b = hexdec(substr($hex,4,2));
   }
   $rgb = array($r, $g, $b);
   //return implode(",", $rgb); // returns the rgb values separated by commas
   return $rgb; // returns an array with the rgb values
}