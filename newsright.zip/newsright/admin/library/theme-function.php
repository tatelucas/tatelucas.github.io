<?php 

function single_author_info(){ ?>
	<div class="author-box">
		<?php echo get_avatar( get_the_author_meta('ID'), 125 ); ?>
		<div class="author-detail">
			<h3><?php the_author_link(); ?></h3>
			<?php the_author_meta( 'description' ); ?> 
		</div>
	</div>
<?php }


function post_media_overlay_title(){ ?>
	<div class="overlay">
		<?php the_title('<h2>','</h2>'); ?>
		<a href="<?php the_permalink(); ?>" class="link"><?php echo __('Read More','mtcfreamwork'); ?></a>
	</div>
<?php 
}


function post_media_overlay_title2(){ ?>
	<div class="overlay">
		<?php the_title('<h2><a href="'.get_permalink().'">','</a></h2>'); ?>
		<?php list_post_meta2(); ?>
		<a href="<?php the_permalink(); ?>" class="link"><?php echo __('Read More','mtcfreamwork'); ?></a>
	</div>
<?php 
}



function mtc_wp_link_pages(){
	wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages : ', 'mtcframework' ), 'after' => '</div>' ) );
}


function mtc_single_post_tags(){ ?>
	<div class="post_panel">
		<?php the_tags('<ul><li>','</li><li>','</li></ul>'); ?>
	</div>
<?php  }



function mtc_thumbnail_blog_thumb(){ ?>
	<div class="thumb">
		<?php if ( has_post_thumbnail() ) { ?>
			<?php the_post_thumbnail('blog-thumb'); ?>
		<?php } else{ ?>
				<img src="<?php echo get_template_directory_uri().'/img/default-blog-thumb.jpg'; ?>" alt="<?php the_title( ); ?>">
		<?php } ?>
		
	</div>
<?php 
}


function mtc_thumbnail_medium(){ ?>
	<div class="thumb">
		<?php if ( has_post_thumbnail() ) { ?>
			<?php the_post_thumbnail('medium'); ?>
		<?php } else{ ?>
			<img src="<?php echo get_template_directory_uri().'/img/default_thumbnail_large.jpg'; ?>" alt="<?php the_title( ); ?>">
		<?php } ?>
		<div class="overlay">
			<a href="<?php the_permalink(); ?>" class="link"><?php echo __('Read More','mtcframework');?></a>
		</div>
	</div>
<?php 
}



function list_post_single_tag(){
	$single_tag = single_tag_post();
	if(!empty($single_tag)){
		echo '<div class="ribbon-label">'.$single_tag.'</div>';
	}
}

function the_excerpt_25(){
	echo '<p class="excerpt">'. excerpt(25) .'</p>';
}

function the_excerpt_15(){
	echo '<p class="excerpt">'. excerpt(15) .'</p>';
}



function mtc_post_meta(){ 
	global $post;
?>
	<div class="post-meta">
		<ul>
			<li class="link-author"><i class="icon-user icon-large"></i> <?php the_author_posts_link(); ?></li>
			<li class="date"><i class="icon-time icon-large"></i> <a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php the_time(get_option('date_format')); ?></a></li>
			<li class="category"><i class="icon-folder-close icon-large"></i> <?php echo single_category_post($post); ?></li>
		</ul>	
	</div>
<?php 
}


function list_post_meta2(){ ?>
	<div class="meta link-2">
		<?php echo __('by','mtcframework');?> <?php the_author_posts_link(); ?> /
		<a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php the_time(get_option('date_format')); ?></a>
	</div>
<?php }


function list_post_meta(){ ?>
	<p class="panel"> 
		<span class="meta_cat"><?php echo single_category_post(); ?></span> /
		<a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php the_time(get_option('date_format')); ?></a> /
		<?php comments_popup_link('No Comments ', '1 Comment', '% Comments'); ?> 
	</p>
<?php }