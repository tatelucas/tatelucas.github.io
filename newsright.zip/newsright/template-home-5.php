<?php 
/*
	Template name: Home Metro
*/

get_header(); ?>
<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">
				<?php 
				
				$number     	= 12;  
				$paged      	= (get_query_var('page')) ? get_query_var('page') : 1;  
				$offset     	= ($paged - 1) * $number;
				
						
				$args_slider = array(	
					'posts_per_page'	=> $number , 
					'post_type' 		=> 'post',
					'offset'       		=> $offset,
					'order'				=> 'DESC', 
					'orderby' 			=> 'post_date',
					'ignore_sticky_posts' => 1
				);
				
				query_posts($args_slider);
				
				$main_content = $slider_content = '';
				
				
				
				if ( have_posts() ) :	
					
					$iterasi = 1;
					$slider_content .= '<div class="slider" id="lates-home-2">';
					
					
					while ( have_posts() ) : the_post();
						if(1 == $paged){
							if(5 >= $iterasi){
							 $slider_content .= get_content_slider_home_2($iterasi);
							}
						
							else{
								$main_content .=  mtc_load_template_part( 'content', get_post_format() );
							}
						}else{
							$main_content .=  mtc_load_template_part( 'content', get_post_format() );
						}
						
						
						$iterasi++;

					endwhile; 
					
					
					$slider_content .= '</div>';
					
				else : 	
					$main_content .= mtc_load_template_part( 'content', 'none' ); 
				endif;		
				
			//	wp_reset_query();		
							
				echo $slider_content;	
						
						
				?>
				<div class="main">
				
					<?php do_action('before_main_content'); ?>
					
					<div class="main-content">
						<?php echo $main_content; ?>
					</div>
					
				
					<?php do_action('after_main_content'); ?>
					
				</div><!-- end main -->				
				<?php get_template_part('sidebar');?>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>