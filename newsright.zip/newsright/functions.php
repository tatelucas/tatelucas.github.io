<?php  
/*
* Mediatechindo framework V.1.0 
*/


if ( get_stylesheet_directory() ==  get_template_directory() ) {
	define('DEN_ROOT',  get_template_directory());
	define('DEN_DIRECTORY', get_template_directory());
	define('DEN_INIT', get_template_directory() . '/init/');
	define('DEN_INCLUDE_URI', get_template_directory_uri() . '/include/');
	define('DEN_INCLUDE', get_template_directory() . '/include/');
	define('DEN_JS', get_template_directory_uri() . '/js/');
	define('DEN_CSS', get_template_directory_uri() . '/css/');
	define('DEN_URI', get_template_directory_uri() );


} else {
	define('DEN_ROOT', get_stylesheet_directory());
	define('DEN_DIRECTORY', get_stylesheet_directory());
	define('DEN_INIT', get_stylesheet_directory() . '/init/');
	define('DEN_INCLUDE_URI', get_stylesheet_directory_uri() . '/include/');
	define('DEN_INCLUDE', get_stylesheet_directory() . '/include/');
	define('DEN_JS', get_stylesheet_directory_uri() . '/js/');
	define('DEN_CSS', get_stylesheet_directory_uri() . '/css/');
	define('DEN_URI', get_stylesheet_directory_uri() );

}

/* set yor language */
load_theme_textdomain('mtcframework', get_template_directory() . '/languages');



require_once ('admin/index.php');
require_once ('admin/library.php');




function get_content_slider_home_2($s=1){ 
	ob_start();
	$class ='';
	if($s==2){
		$class='sbig';
	}
	?>
	<div <?php post_class($class); ?>>
		<div class="post-media-slider">
			<div class="thumb">
				<?php if ( has_post_thumbnail() ) { ?>
					<?php the_post_thumbnail('medium-square'); ?>
				<?php } else{ ?>
						<img src="<?php echo get_template_directory_uri().'/img/default-blog-thumb.jpg'; ?>" alt="<?php the_title( ); ?>">
				<?php } ?>
			</div>
			<?php post_media_overlay_title(); ?>
		</div>
	</div>
	<?php 
	$content = ob_get_clean();
	return $content;
}




function mtc_load_template_part($slug='',$name =''){
	ob_start();
	get_template_part( $slug, $name );
	$content = ob_get_clean();
	return $content;
}









function mtc_enq_style() {
	wp_register_style('style', DEN_URI . '/style.css', 'style');
	wp_register_style('rtl', DEN_URI . '/rtl.css', 'style');
	wp_register_style('bootstrap', DEN_CSS . 'bootstrap.css', 'style');
	wp_register_style('bootstrap-responsive', DEN_CSS . 'bootstrap-responsive.css', 'style');
	wp_register_style('font-awesome', DEN_CSS . 'font-awesome.min.css', 'style');
	wp_register_style('animate', DEN_CSS . 'animate.css', 'style');
	wp_register_style('woocommerce-custom', DEN_CSS . 'woocommerce-custom.css', 'style');
	wp_register_style('responsive', DEN_CSS . 'responsive.css', 'style');
	wp_register_style('bbpress-custom', DEN_CSS . 'bbpress-custom.css', 'style');
	
	wp_enqueue_style( 'font-awesome');
	wp_enqueue_style( 'bootstrap');
	wp_enqueue_style( 'bootstrap-responsive');
	wp_enqueue_style( 'animate');
	wp_enqueue_style( 'jquery.fancybox',DEN_CSS . 'jquery.fancybox.css', '','2.1.4','screen',TRUE);
	wp_enqueue_style( 'jquery.bxslider',DEN_CSS . 'jquery.bxslider.css', '','4.1','screen',TRUE);
	wp_enqueue_style( 'style');
	wp_enqueue_style( 'woocommerce-custom');
	wp_enqueue_style( 'bbpress-custom');
	wp_enqueue_style( 'responsive');
	wp_enqueue_style( 'custumizer',DEN_CSS . 'customizer.css.php', 'style','1.0','screen',TRUE);

	do_action('mtc_enq_style');
}
add_action('wp_enqueue_scripts', 'mtc_enq_style',100);







function mtc_enq_scripts() {
	wp_enqueue_script('jquery');
	wp_enqueue_script('selectnav', DEN_JS  . 'selectnav.min.js',array( 'jquery' ), '1', TRUE); 
	wp_enqueue_script('jquery.ticker', DEN_JS  . 'jquery.ticker.js','','',TRUE);
	wp_enqueue_script('bootstrap', DEN_JS  . 'bootstrap.min.js',array( 'jquery' ), '20120206', TRUE);
	wp_enqueue_script('jquery.bxslider', DEN_JS  . 'jquery.bxslider.js','4.1','',TRUE);
	wp_enqueue_script('jquery.carouFredSel', DEN_JS  . 'jquery.carouFredSel.js','6.2.1','',TRUE);
	wp_enqueue_script('jquery.fancybox', DEN_JS  . 'jquery.fancybox.pack.js','2.1.4','',TRUE);
	wp_enqueue_script('jquery.sticky', DEN_JS  . 'jquery.sticky.js','2.1.4','',TRUE);
	wp_enqueue_script('fluidvids', DEN_JS  . 'fluidvids.min.js','2.0.0','',TRUE);
	wp_enqueue_script('waypoints', DEN_JS  . 'waypoints.min.js','2.0.0','',TRUE);
	wp_enqueue_script('imagesloaded', DEN_JS  . 'imagesloaded.pkgd.min.js','2.0.0','',TRUE);
	wp_enqueue_script('masonry', DEN_JS  . 'masonry.pkgd.min.js','2.0.0','',TRUE);
	
	if ( is_page_template('template-contact.php') ) {
		wp_enqueue_script('gmapsapi','http://maps.google.com/maps/api/js?sensor=false','','',true);
		wp_enqueue_script('gmaps',get_template_directory_uri() . '/js/gmaps.js','','',true);
	}
	
	wp_enqueue_script('theme', DEN_JS  . 'theme.js','','',TRUE);
}
add_action( 'wp_enqueue_scripts', 'mtc_enq_scripts',999 );








/* custom login */
function mtc_custom_login_logo() {
	global $smof_data;
	$custom_logo = $smof_data['login_logo'];
	if ($custom_logo) {		
	echo '<style type="text/css">
		.login h1 a { background-image:url('. $custom_logo .') !important; height: 95px!important; background-size: auto; width:auto;}
	</style>';
	} else {
	echo '<style type="text/css">
		.login h1 a { background-image:url('. get_template_directory_uri() .'/img/login-logo.png) !important; height: 95px!important; background-size: auto; width:auto;}
	</style>';
	}
}
add_action( 'login_enqueue_scripts', 'mtc_custom_login_logo');







/* add favicon standar and apple touch icon */
if(!function_exists('mtc_favicon')){
	function mtc_favicon(){
		global $smof_data;
		if(!empty($smof_data['custom_favicon'])){ 
			?><link rel="shortcut icon" href="<?php echo $smof_data['custom_favicon']; ?>" /><?php 
		} else { 
			?><link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon.png" /><?php
		} 
		
		if(!empty($smof_data['appletouchicon_57'])) 	: ?><link rel="apple-touch-icon-precomposed" href="<?php echo $smof_data['appletouchicon_57']; ?>" /><?php endif;
		if(!empty($smof_data['appletouchicon_72'])) 	: ?><link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo $smof_data['appletouchicon_72']; ?>" /><?php endif; 
		if(!empty($smof_data['appletouchicon_114'])) 	: ?><link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo $smof_data['appletouchicon_114']; ?>" /><?php endif; 
		if(!empty($smof_data['appletouchicon_144'])) 	: ?><link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo $smof_data['appletouchicon_144']; ?>" /><?php endif; 
		
	}
	add_action( 'wp_head', 'mtc_favicon' );
}






/* add fancybox link support */
if(!function_exists('add_data_fancybox_group_galery')){
	function add_data_fancybox_group_galery($content) {
		$content = preg_replace("/<a/","<a data-fancybox-group=\"gallery-fancybox-group\"",$content,1);
		return $content;
	}
	add_filter( 'wp_get_attachment_link', 'add_data_fancybox_group_galery'); 
}






if(!function_exists('mtc_filter_widget_title')){
	function mtc_filter_widget_title($title) {
		$new_title = '';
		
		if ( $title){
			$title_explode = explode('||', $title);
			
			if(isset($title_explode[1])){
				$new_title .= '<span class="outer">'. trim($title_explode[1]).'</span>';
			}
			
			$new_title .= $title_explode[0];
		}
		
		return $new_title;
	}
	add_filter( 'widget_title', 'mtc_filter_widget_title'); 
}










if(!function_exists('mtc_custom_style')){
	function mtc_custom_style(){
		global $smof_data;
		
		$css = '';
		
		if('left'==$smof_data['scroll_pos']){
			$css.='#back-top { '. $smof_data['scroll_pos'] .':30px; right:auto }';
		}

		wp_add_inline_style( 'custumizer', $css );
	}
	
	add_action( 'wp_print_styles', 'mtc_custom_style' );
}




					
					
if(!function_exists('mtc_custom_css')){
	function mtc_custom_css(){
		global $smof_data;

		/* Custom  CSS */
		if(!empty($smof_data['custom_css'])) {
			echo '<style type="text/css" media="all">'.$smof_data['custom_css'].'</style>';
		}
	}
	
	add_action( 'wp_head', 'mtc_custom_css',999 );
}



if(!function_exists('mtc_custom_script')){
	function mtc_custom_script(){
		global $smof_data;
		/* Custom Tracking Code */
		if(!empty($smof_data['google_analytics'])) {
			echo '<script type="text/javascript">'.$smof_data['google_analytics'].'</script>'; 	
		}
	}
	
	add_action( 'wp_footer', 'mtc_custom_script',999 );
}



if(!function_exists('themeSetting_var_localize_script')){
	function themeSetting_var_localize_script(){
		global $smof_data;
		
		wp_localize_script( 'theme', 'themeSetting', array (
			'base_url' 					=> admin_url( 'admin-ajax.php' ),
			'slider_effect' 			=> $smof_data['slider_effect'] ,
			'slider_timeoutDuration' 	=> $smof_data['slider_timeoutDuration'] ,
		));
		
	}
	add_action( 'wp_footer', 'themeSetting_var_localize_script' );
}









if(!function_exists('pagination')){
function pagination($pages = '', $range = 4) { 	
	$prev = get_previous_posts_link('PREV');
	$next = get_next_posts_link('NEXT');
	
    $showitems = ($range * 2)+1; 
 
    global $paged;
    if(empty($paged)) $paged = 1;
 
    if($pages == ''){
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages){
             $pages = 1;
         }
     }  
	
    if(1 != $pages){
        echo '<div class="pagination"><ul>';
		if(!empty($prev)){
			echo '<li>'.$prev.'</li>';
		}

		for ($i=1; $i <= $pages; $i++){
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )){
                 echo ($paged == $i)? "<li class=\"disabled\"><a href=\"#\">".$i."</a></li>":"<li><a href='".get_pagenum_link($i)."' >".$i."</a></li>";
            }
        }
 
		if(!empty($next)){
			echo '<li>'.$next.'</li>';
		}
		 echo '</ul></div>';
     }
}
}





/* show social icon */
if(!function_exists('mtc_social_media')){
	function mtc_social_media(){
		global $smof_data;
		$output = '';
		$social = array(
					's_facebook' 	=>array('Facebook','icon-facebook'),
					's_twitter'		=>array('Twitter','icon-twitter'),
					's_instagram'	=>array('Instagram','icon-instagram'),
					's_Linkedin'	=>array('Linkedin','icon-linkedin'),
					's_Dribbble'	=>array('Dribbble','icon-dribbble'),
					's_YouTube'		=>array('YouTube','icon-youtube'),
					's_Pinterest'	=>array('Pinterest','icon-pinterest'),
					's_Flickr'		=>array('Flickr','icon-flickr'),
					's_Tumblr'		=>array('Tumblr','icon-tumblr'),
					's_Rss'			=>array('RSS','icon-rss'),
					's_github'		=>array('Github','icon-github'),
					's_Google'		=>array('Circle G+','icon-google-plus-sign')
				);
				
		$output .= '<ul class="mtc_social">';
		
		foreach($social as $key=>$val){
		
			if(isset($smof_data[$key])){
			
				if(!empty($smof_data[$key])){ 
				
					$class 	 = 'social_'.str_replace('-','_', $val[1]);
					$output .= '<li>';	
					$output .= '<a class="'.$class.'" href="' . $smof_data[$key] . '" title="' . $val[0] . '"><i class="icon ' . $val[1] . '"></i></a>';	
					$output .= '</li>';	
				}
			}
		}	
		
		$output .= '</ul>';						

		return $output;
	}
}






/* add bottom scroll top */
if(!function_exists('mtc_back_to_top')){
	function mtc_back_to_top(){
		global $smof_data;
		
		if($smof_data['switch_scrooltop']) : 
			?><div id="back-top"><a href="#top"><i class="icon-angle-up"></i></a></div><?php 
		endif; 
	}
	add_action( 'wp_footer', 'mtc_back_to_top',999 );
}







/* 
 *
 *	Show feature image on post list
 *
 */
if(!function_exists('_mtc_add_style_custom_list_table')){
	function _mtc_add_style_custom_list_table(){
		?><style type="text/css" media="all">.column-mtc_icon{width:50px;}</style><?php
	}
	add_action('admin_head', '_mtc_add_style_custom_list_table');
}





if(!function_exists('mtc_set_custom_edit_post_columns')){
	function mtc_set_custom_edit_post_columns($columns) {
		$new_columns = array();
		$new_columns['cb'] = $columns['cb'];
		$new_columns['mtc_icon'] = __( 'Image', 'mtcframework' );
		
		foreach($columns as $key=>$val){
			 $new_columns[$key] =$val;
		}
		return $new_columns;
	}
	add_filter( 'manage_edit-post_columns', 'mtc_set_custom_edit_post_columns' );
}





if(!function_exists('mtc_custom_post_column')){
	function mtc_custom_post_column( $column, $post_id ) {
		switch ( $column ) {

			case 'mtc_icon' :
				if ( has_post_thumbnail() ) {
					the_post_thumbnail(array(50,50));
				}else{
					echo ' ';
				}
				break;
		}
	}
	add_action( 'manage_post_posts_custom_column' , 'mtc_custom_post_column', 10, 2 );
}









/* = Boxed and Wide Layout Class 
***************************************************/
if(!function_exists('mtc_boxed_class')){
	function mtc_boxed_class(){
		global $smof_data; 
		$class = '';
		if($smof_data['layout_style']=='wide'){
			$class = 'boxed';
		}
		else{
			$class = 'boxed active';
		}	
		echo 'class="'. $class .'"';	
	}
}







/**
* Extended Walker class for use with the
* Twitter Bootstrap toolkit Dropdown menus in Wordpress.
* Edited to support n-levels submenu.
* @author johnmegahan https://gist.github.com/1597994, Emanuele 'Tex' Tessore https://gist.github.com/3765640
*/
class Mtc_Nav_Menu_Walker extends Walker_Nav_Menu {
	function start_lvl( &$output, $depth = 0, $args = array() ) {

		$indent = str_repeat( "\t", $depth );
		/* $submenu = ($depth > 0) ? ' sub-menu' : ''; */
		$output	   .= "\n$indent<ul class=\" depth_$depth\">\n";

	}
	
	function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {

		$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

		$li_attributes = '';
		$class_names = $value = '';

		$classes = empty( $item->classes ) ? array() : (array) $item->classes;
		
		// managing divider: add divider class to an element to get a divider before it.
		$divider_class_position = array_search('divider', $classes);
		if($divider_class_position !== false){
			$output .= "<li class=\"divider\"></li>\n";
			unset($classes[$divider_class_position]);
		}
		
		$classes[] = ($args->has_children) ? 'dropdown' : '';
		$classes[] = ($item->current || $item->current_item_ancestor) ? 'active' : '';
		$classes[] = 'menu-item-' . $item->ID;
		if($depth && $args->has_children){
			/* $classes[] = 'dropdown-submenu'; */
		}


		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
		$class_names = ' class="' . esc_attr( $class_names ) . '"';

		$id = apply_filters( 'nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args );
		$id = strlen( $id ) ? ' id="' . esc_attr( $id ) . '"' : '';

		$output .= $indent . '<li' . $id . $value . $class_names . $li_attributes . '>';

		$attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
		$attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
		$attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
		$attributes .= ! empty( $item->url )        ? ' href="'   . esc_attr( $item->url        ) .'"' : '';
		/* $attributes .= ($args->has_children) 	    ? ' class="dropdown-toggle bl-dropdown" data-toggle="dropdown"' : ''; */

		$item_output = $args->before;
		$item_output .= '<a'. $attributes;

		$item_output .= ' >';
		$item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
		$item_output .= ($depth == 0 && $args->has_children) ? ' <i class="icon-angle-down"></i></a>' : '</a>';
		
		$item_output .= $args->after;


		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}
	
	
	function display_element( $element, &$children_elements, $max_depth, $depth=0, $args, &$output ) {
		//v($element);
		if ( !$element )
			return;

		$id_field = $this->db_fields['id'];

		//display this element
		if ( is_array( $args[0] ) )
			$args[0]['has_children'] = ! empty( $children_elements[$element->$id_field] );
		else if ( is_object( $args[0] ) )
			$args[0]->has_children = ! empty( $children_elements[$element->$id_field] );
		$cb_args = array_merge( array(&$output, $element, $depth), $args);
		call_user_func_array(array(&$this, 'start_el'), $cb_args);

		$id = $element->$id_field;

		// descend only when the depth is right and there are childrens for this element
		if ( ($max_depth == 0 || $max_depth > $depth+1 ) && isset( $children_elements[$id]) ) {

			foreach( $children_elements[ $id ] as $child ){

				if ( !isset($newlevel) ) {
					$newlevel = true;
					//start the child delimiter
					$cb_args = array_merge( array(&$output, $depth), $args);
					call_user_func_array(array(&$this, 'start_lvl'), $cb_args);
				}
				$this->display_element( $child, $children_elements, $max_depth, $depth + 1, $args, $output );
			}
			unset( $children_elements[ $id ] );
		}

		if ( isset($newlevel) && $newlevel ){
			//end the child delimiter
			$cb_args = array_merge( array(&$output, $depth), $args);
			call_user_func_array(array(&$this, 'end_lvl'), $cb_args);
		}

		//end this element
		$cb_args = array_merge( array(&$output, $element, $depth), $args);
		call_user_func_array(array(&$this, 'end_el'), $cb_args);

	}

}






/* 
 * 
 * define a socmed data for user meta socmed
 *
 */
global $socmed_user;

$socmed_user = array(
	array(
		'title'		=>'Twitter',
		'id'		=> 'twitter',
		'icon'		=> 'icon-twitter',
		'message' 	=> __('Your profile link on Twitter. ex : https://twitter.com/username','mtcframework')
	),
	array(
		'title'		=>'Facebook',
		'id'		=> 'facebook',
		'icon'		=> 'icon-facebook',
		'message' 	=> __('Your profile link on Facebook. ex : http://www.facebook.com/username','mtcframework')
	),
	array(
		'title'		=>'Google Plus',
		'id'		=> 'google_plus',
		'icon'		=> 'icon-google-plus-sign',
		'message' 	=> __('Your profile link on Google Plus. ex : https://plus.google.com/+username','mtcframework')
	),
	array(
		'title'		=>'Linkedin',
		'id'		=> 'linkedin',
		'icon'		=> 'icon-linkedin',
		'message' 	=> __('Your profile link on Linkedin. ex : http://www.facebook.com/username','mtcframework')
	),
	array(
		'title'		=>'Dribbble',
		'id'		=> 'dribbble',
		'icon'		=> 'icon-dribbble',
		'message' 	=> __('Your profile link on Dribbble. ex : http://www.dribbble.com/username','mtcframework')
	),array(
		'title'		=>'Pinterest',
		'id'		=> 'pinterest',
		'icon'		=> 'icon-pinterest',
		'message' 	=> __('Your profile link on Pinterest. ex : http://www.pinterest.com/username','mtcframework')
	),array(
		'title'		=>'Flickr',
		'id'		=> 'flickr',
		'icon'		=> 'icon-flickr',
		'message' 	=> __('Your profile link on Flickr. ex : http://www.flickr.com/username','mtcframework')
	),array(
		'title'		=>'Tumblr',
		'id'		=> 'tumblr',
		'icon'		=> 'icon-tumblr',
		'message' 	=> __('Your profile link on Tumblr. ex : http://www.tumblr.com/username','mtcframework')
	),array(
		'title'		=>'Github',
		'id'		=> 'github',
		'icon'		=> 'icon-github',
		'message' 	=> __('Your profile link on Github. ex : http://www.github.com/username','mtcframework')
	),
	array(
		'title'		=>'Youtube',
		'id'		=> 'youtube',
		'icon'		=> 'icon-youtube',
		'message' 	=> __('Your profile link on Youtube. ex : http://www.youtube.com/user/username','mtcframework')
	)
);



/* 
	Add meta user on admin page
*/
if(!function_exists('mtc_input_user_socmed_link')){
	function mtc_input_user_socmed_link( $user ) { ?>
		<h3><?php echo __('Social Media Link','mtcframework');?></h3>
		<table class="form-table">
			<?php 
			global $socmed_user;
			/* Render the form */
			foreach($socmed_user as $soc){ ?>
				<tr>
					<th>
						<label for="<?php echo $soc['id']; ?>"><?php echo $soc['title']; ?></label>
					</th>
					<td>
						<input type="text" name="mtc_meta_socmed[<?php echo $soc['id']; ?>]" id="<?php echo $soc['id']; ?>" value="<?php echo esc_attr( get_the_author_meta( $soc['id'], $user->ID ) ); ?>" class="regular-text" /><br />
						<span class="description"><?php echo $soc['message']; ?></span>
					</td>
				</tr><?php
			} ?>
		</table>
	<?php }
	add_action( 'show_user_profile', 'mtc_input_user_socmed_link' );
	add_action( 'edit_user_profile', 'mtc_input_user_socmed_link' );
}





/* 
	PART of function mtc_input_user_socmed_link();
	this function is callback function for save the meta data user
*/
if(!function_exists('mtc_save_user_socmed_link')){
	function mtc_save_user_socmed_link( $user_id ) {

		if ( !current_user_can( 'edit_user', $user_id ) )
			return false;
		
		$meta_socmed = $_POST['mtc_meta_socmed'];
		
		foreach($meta_socmed as $id_socmed => $val_socmed){
			$val_socmed = trim($val_socmed);
			update_user_meta( $user_id, $id_socmed, $val_socmed );
		}
	}
	add_action( 'personal_options_update', 'mtc_save_user_socmed_link' );
	add_action( 'edit_user_profile_update', 'mtc_save_user_socmed_link' );
}







/* = Comments list
************************************************************/
if(!function_exists('mtc_comments')){
function mtc_comments($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
	<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>" class="comment even thread-even depth-1">
	<div class="rapidx_comment" id="comment-2223">
		<div class="comment-meta commentmetadata">
			<cite class="fn"><?php printf(__('%s','mtcframework'), get_comment_author_link()) ?></cite>
			<div class="clock">
				<?php comment_time('F j, Y ');?> at <?php comment_time('H:i a'); ?>, 
				<?php //edit_comment_link(__(' Edit , '),'<span class="edit-comment">', '</span>'); ?>
				<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
			</div>
		</div>
		
		<div class="comment-body">
			<?php comment_text() ?>
		</div>
	</div>
	<div class="comment-author vcard"><?php echo get_avatar($comment,$size='125'); ?></div>						
	<div class="reply"></div>
	<?php 
	
	/* </li> is added  automatically */
	
} // don't remove this bracket! 
}





/* From news right negin here */
function single_tag_post(){
	global $post;
	$tags = get_the_tags($post->ID);
	if(is_array( $tags)){
		foreach ($tags as $tag):
		endforeach;
		return '<a href="'.get_tag_link($tag->term_id).'">'.$tag->name.'</a>';
	}
	return false;
}



function single_category_post(){
	global $post;
	$cats = get_the_category($post->ID);
	if(is_array( $cats)){
		if(count($cats) !=0){
			foreach ($cats as $cat):
			endforeach;
			return '<a href="'.get_category_link($cat->term_id).'">'.$cat->name.'</a>';
		}else{
			return false;
		}
	}
	return false;
}



function mtc_random_author(){
	global $smof_data;
	if( 1 == $smof_data['switch_random_author_home']){
		get_template_part('list-of-author');
	}
}




function mtc_relate_post(){ ?>
	<div class="post-relate"><?php  
		global $post;
		$tags = wp_get_post_tags($post->ID);  
		if ($tags) :  
			$tag_ids = array();  
			foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;  
			  
			$args=array(  
				'tag__in' 		=> $tag_ids,  
				'post__not_in' 	=> array($post->ID),  
				'showposts'		=>4,  	// Number of related posts that will be shown.  
				'ignore_sticky_posts'	=>1  
			);  
			  
			$my_query = new wp_query($args);  
			if( $my_query->have_posts() ) :  ?>
				<h3><span class="outer">Post By Related</span>Related Post</h3>
				<ul class="relatepost">
				<?php
				while ($my_query->have_posts()) :  
					$my_query->the_post(); 
					?>
					<li>
						<div class="post-imgthumb">
							<?php if ( has_post_thumbnail() ) :   the_post_thumbnail('thumbnail');  else :  ?>
								<img src="<?php echo get_template_directory_uri();?>/img/thumb_150.jpg" alt="image"/>
							<?php endif;?>
						</div>
						<h4 class="link-2">
							<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h4>
						<?php do_action('mtc_relate_post_after_title'); ?>
						
					</li>  
				<?php endwhile;  
				echo '</ul>'; 
			endif;    
		endif;  
		/* $post = $backup;   */
		wp_reset_query();
	?></div><!-- end post-relate -->
<?php }




function mtc_limit_the_text($text, $limit=10) {
	$excerpt = explode(' ', $text, $limit);
	
	if (count($excerpt)>=$limit) {
		array_pop($excerpt);
		$excerpt = implode(" ",$excerpt).'...';
	} else {
		$excerpt = implode(" ",$excerpt);
	}
	$excerpt = preg_replace('`[[^]]*]`','',$excerpt);
	return $excerpt;
}






global $custom_field_user;
$custom_field_user = array(
	array(
		'name' => 'profession',
		'label' => 'Profession',
		'des' => __('Type your Profession.','mtcframework'),
		'type' => 'input'
	)
);





/*  Add meta user on admin page */
if(!function_exists('mtc_show_extra_profile_fields')){

function mtc_show_extra_profile_fields( $user ) {   ?>
<h3><?php echo __('Extra profile information','mtcframework');?></h3>
<table class="form-table">
	<?php 
	global $custom_field_user;
	foreach($custom_field_user as $field){ ?>
	<tr>
		<th><label for="<?php echo $field['name']; ?>_profile"><?php echo $field['label']; ?></label></th>
		<td>
			<?php if('input' == $field['type']) { ?>
				<input type="text" name="<?php echo $field['name']; ?>" id="<?php echo $field['name']; ?>_profile" value="<?php echo esc_attr( get_the_author_meta( $field['name'], $user->ID ) ); ?>" class="regular-text" />
			<?php } if('textarea' == $field['type']) { ?>
				<textarea name="<?php echo $field['name']; ?>" id="<?php echo $field['name']; ?>_profile" class="regular-text" cols="30" rows="5"><?php echo esc_attr( get_the_author_meta( $field['name'], $user->ID ) ); ?></textarea>
			<?php } ?>
			<br />
			<span class="description"><?php echo $field['des']; ?></span>
		</td>
	</tr>
	<?php } ?>
</table>
<?php }
add_action( 'show_user_profile', 'mtc_show_extra_profile_fields' );
add_action( 'edit_user_profile', 'mtc_show_extra_profile_fields' );
}




/* 
	PART of function wy_save_extra_profile_fields();
	this function is callback function for save the meta data user 
*/
if(!function_exists('mtv_save_extra_profile_fields')){
	function mtv_save_extra_profile_fields( $user_id ) {
		global $custom_field_user;
		if ( !current_user_can( 'edit_user', $user_id ) )
			return false;

		foreach($custom_field_user as $field){ 
			update_user_meta( $user_id , $field['name'] , $_POST[$field['name']] );
		}
	}
	add_action( 'personal_options_update', 'mtv_save_extra_profile_fields' );
	add_action( 'edit_user_profile_update', 'mtv_save_extra_profile_fields' );
}




/**
 * user profile
 * 
 */	 
add_action( 'admin_enqueue_scripts', 'mtc_admin_custom' );
function mtc_admin_custom(){
	wp_enqueue_media();
	wp_enqueue_script( 'mtccustomupload', get_template_directory_uri() . '/js/admincustom.js' );
} 


function mtc_extra_user_profile_fields( $user ) { ?>
<table class="form-table">
<tr>
	<th><label for="profile_picture"><?php _e("Profile Picture", "mtcframework"); ?></label></th>
	<td>
		<img class="regular-text custom_media_image" width="200" src="<?php echo esc_attr( get_the_author_meta( 'profile_picture', $user->ID ) ); ?>" /><br />
		<input class="regular-text custom_media_url" type="text" name="profile_picture" id="profile_picture" value="<?php echo esc_attr( get_the_author_meta( 'profile_picture', $user->ID ) ); ?>"> <br />
		<a href="#" class="custom_media_upload">Upload</a> <br />
		<span class="description"><?php _e("Please enter your profile picture.", "mtcframework"); ?></span>
	</td>
</tr>
</table>
<?php }
add_action( 'show_user_profile', 'mtc_extra_user_profile_fields' );
add_action( 'edit_user_profile', 'mtc_extra_user_profile_fields' );




function save_extra_user_profile_fields( $user_id ) {

	if ( !current_user_can( 'edit_user', $user_id ) ) { return false; }

	update_user_meta( $user_id, 'profile_picture', $_POST['profile_picture'] );

}
add_action( 'personal_options_update', 'save_extra_user_profile_fields' );
add_action( 'edit_user_profile_update', 'save_extra_user_profile_fields' );