jQuery.noConflict();
var $=jQuery.noConflict();

(function($) {
	"use strict";
	
	$.fn.mtcimgfluid = function() {
		this.each(function(i){
			flx($(this));
			console.log('d');
		});
	};
	
	var flx = function(t){
		var h = t.height();
		var w = t.width();
		var p = t.parent();
		var ph= p.height();
		var pw= p.width();
		
		t.removeAttr('width');
		t.removeAttr('height');
		
		if(h < ph){
			t.height(ph);
			t.width((ph/h) * w);
			t.css('maxWidth','999px')
		}
	}
	
})(jQuery);






jQuery(function () {

	"use strict";
	// Toggle menu navigasi 
	$(".topnav_toggle").click(function(){
		$(".nav").slideToggle("");
	});
	
	$(document).ready(function(){
		if ($(".masonry-1").size()){
			/* Add Masonry layout on home 2 */
			var $container = $('.masonry-1');
			// initialize Masonry after all images have loaded  
			$container.imagesLoaded( function() {
			  $container.masonry();
			});

		}
	});
	
	$(document).ready(function(){
		if ($("#lates-home-2").size()){
			/* Add Masonry layout on home 2 */
			var $container = $('#lates-home-2');
			// initialize Masonry after all images have loaded  
			$container.imagesLoaded( function() {
			  $container.masonry();
			});

		}
	});
	
	
				
	/* 
	$('.post-list, .list_post, .products .product, .post_row, .widget').waypoint(function(direction) {
		$(this).addClass('animated fadeInDown');
	}, {
		offset: '80%' // Apply "stuck" when element 30px from top
	});  */

	
	
	/* Add tool tip on news picture */
	/* $('.list_mini a').tooltip(); */
	
	$( document ).ready(function() {
		$('li.product-category .wrap-product img, .list-v3-large img, .list_home .thumb img').mtcimgfluid();
	});
	
	
	/* Fix responsive videos */
	Fluidvids.init({
		selector: ['iframe','video'],
		players: [
			'www.youtube.com', 
			'player.vimeo.com',
			/* 'w.soundcloud.com' */
		]
	});
	
	
	
	/* add  fancybox to gallery default where click*/
	$(".gallery-icon a").fancybox({
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	
	
	
	/* slider product categori. home shop */
	$('.full_shop_slider .products').bxSlider({
		slideWidth: 265	,
		minSlides: 2,
		maxSlides: 4,
		//pagerSelector: '#news-latest',
		adaptiveHeight:true,
		//pager:false,
		//prevSelector: $('#nav-slider-latest-product'),
		//nextSelector: $('#nav-slider-latest-product'),
		nextText: '<i class="icon-angle-right"></i>',
		prevText: '<i class="icon-angle-left"></i>',
		responsive: true,
		slideMargin: 30 
	});
	
	
	
	
	/* slider to news scrool video bigger */
	$('.slide-shop .products').bxSlider({
		slideWidth: 360,
		minSlides: 2,
		maxSlides: 3,
		//pagerSelector: '#news-latest',
		//adaptiveHeight:true,
		pager:false,
		prevSelector: $('#nav-slider-latest-product'),
		nextSelector: $('#nav-slider-latest-product'),
		nextText: '<i class="icon-angle-right"></i>',
		prevText: '<i class="icon-angle-left"></i>',
		responsive: true,
		slideMargin: 30 
	});
	
	/* slider to news scrool video bigger */
	$('.box_list_home').bxSlider({
		slideWidth: 266,
		minSlides: 3,
		maxSlides: 3,
		pager:true,
		pagerSelector: '#news-latest',
		adaptiveHeight:true,
		controls:false,
		responsive: true,
		slideMargin: 20 
	});
	
	$('.csw-content').each(function(){
		var nav = $(this).prev('.csw-nav');
		$(this).bxSlider({
			slideWidth: 100,
			minSlides: 3,
			maxSlides: 3,
			pager:false,
			adaptiveHeight:true,
			prevSelector: nav,
			nextSelector: nav,
			nextText: '<i class="icon-angle-right"></i>',
			prevText: '<i class="icon-angle-left"></i>',
			slideMargin: 5 
		}); 
	});
		
			
			
	/* slider to news scrool video small  */
	if ($("#latest_vid").size()){
		$('#latest_vid').bxSlider({
			/* slideWidth: 260, */
			slideWidth: 273,
			minSlides: 3,
			maxSlides: 6,
			pager:false,
			adaptiveHeight:true,
			prevSelector: $('#latest2'),
			nextSelector: $('#latest2'),
			nextText: '<i class="icon-angle-right"></i>',
			prevText: '<i class="icon-angle-left"></i>',
			slideMargin: 16 
		}); 
	}
	
	
	
	/*  fixed mainmenunav if scroll down*/
	//$("._main_navigation").sticky({ topSpacing: 0 });
	
	
	
	if ($('.box-list-vid-v3').size()){
		$(".box-list-vid-v3").carouFredSel({
			width	: '100%',
			auto: false,
			items	: 3,
			scroll	: 3,
			prev    : {
				button  : "#vid-v3_prev",
				key     : "left"
			},
			next    : {
				button  : "#vid-v3_next",
				key     : "right"
			}
		});
	}
	
	
	
	if ($('#latest-2').size()){
		$("#latest-2").carouFredSel({
			width	: '100%',
			auto: false,
			items	: 2,
			scroll	: 2,
			prev    : {
				button  : "#latest-2_prev",
				key     : "left"
			},
			next    : {
				button  : "#latest-2_next",
				key     : "right"
			}
		});
	}
	
	if ($('.foo2').size()){
		$(".foo2").carouFredSel({
			/* width	: 1170, */
			width	: "100%",
			responsive: true,
			/* items	: 4, */
			items		: {
				width		: 263,
				visible		: {
					min			: 1,
					max			: 4
				}
			},
			scroll	: 4,
			prev    : {
				button  : "#foo2_prev",
				key     : "left"
			},
			next    : {
				button  : "#foo2_next",
				key     : "right"
			}
		});
	} 
/* 	$(".foo2").carouFredSel({
	width	: "100%",
	scroll	: 2
}); */
	
	
	
	
	/* Slideshow 1 */
	if ($('#carousel-1 div').size()){
		var $imgs = $('#carousel-1 div'), $capt3 = $('#captions-1 .list_c'), $timer = $('#timer');
		$imgs.carouFredSel({
			circular: true,
			responsive: true,
			width: "100%",
			auto:false,
			items		: {
				width: 1080,
				height  : "460", 
				visible	: 1
			},
			scroll: {
				fx : themeSetting.slider_effect, /* directscroll , crossfade, cover-fade  	 */
				easing : 'swing',
				duration : 1,
				pauseOnHover : true,
				timeoutDuration : parseInt(themeSetting.slider_timeoutDuration),
				onAfter : function( data ){
					
				},
				onBefore : function( data ) {
					$capt3.trigger( data.scroll.direction);
				}
			},
			onCreate: function (data) {
				
				
			},
			pagination: ".pager",
			prev: {
				button: $('.nav-prev'),
				key:'left'
			},
			next: {
				button: $('.nav-next'),
				key:'right'
			}
		});	 
		
		$capt3.carouFredSel({
			circular: true,
			auto: false,
			responsive: true,
			width: '100%',
			scroll: {
				easing	: 'quadratic',
				duration: 1,
				fx		: themeSetting.slider_effect
			}
		});
	}
	
	
	
	
	/* Slideshow Home 1 
	*************************************************************************************/
	if ($('#carousel div').size()){
		var $imgs = $('#carousel div'), $capt = $('#captions .list_c'), $timer = $('#timer');
		$imgs.carouFredSel({
			circular: true,
			responsive: true,
			items		: {
				width	: 760,
				height  : "56.5789473684%", // 480 	
				visible	: 1
			},
			scroll: {
				fx : themeSetting.slider_effect, // directscroll , crossfade, cover-fade  	
				easing : 'swing',
				duration : 1,
				pauseOnHover : true,
				timeoutDuration :  parseInt(themeSetting.slider_timeoutDuration),
				onBefore : function( data ) {
					$capt.trigger( data.scroll.direction);
					$timer.stop().animate({opacity: 0}, data.scroll.duration); 	
				},
				onAfter : function() {
					$timer.stop().animate({ opacity: 1}, 150); 	
				}
			},
			auto: {
				progress: '#timer'
			},
			pagination: ".pager",
			prev: {
				button: $('.nav-prev'),
				key:'left'
			},
			next: {
				button: $('.nav-next'),
				key:'right'
			}
		});	 
		
		$capt.carouFredSel({
			circular: true,
			auto: false,
			responsive: true,
			width: '100%',
			height: 'variable',
			scroll: {
				easing	: 'quadratic',
				duration: 1,
				fx		: themeSetting.slider_effect
			}
		});
	}
	
	  
});









jQuery(function () {
	
	"use strict";
	
	jQuery("<select />").appendTo("#dropmenu");
	jQuery("<option />", {
	   "selected": "selected",
	   "value"   : "",
	   "text"    : "Go to..."
	}).appendTo("#dropmenu select");
	
	jQuery(".main-navigation").children('ul').children('li').each(function() {
		var href = jQuery(this).children('a').attr('href');
        var text = jQuery(this).children('a').text();
		
		/* Append this option to our "select" */
         jQuery('#dropmenu select').append('<option value="'+href+'">'+text+'</option>');
		 
         /* Check for "children" and navigate for more options if they exist */
         if (jQuery(this).children('ul').length > 0) {
            jQuery(this).children('ul').children('li').each(function() {
               /* Get child-level link and text */
               var href2 = jQuery(this).children('a').attr('href');
               var text2 = jQuery(this).children('a').text();
			   
               /* Append this option to our "select" */
               jQuery('#dropmenu select').append('<option value="'+href2+'">--- '+text2+'</option>');
            });
         }
		 
		 //make responsive dropdown menu actually work			
		jQuery("#dropmenu select").change(function() {
			window.location = jQuery(this).find("option:selected").val();
		});
	
	});
	
	
	/* fade in #back-top */
	/* Default hide button */
	jQuery("#back-top").hide();
	
	/* show hide button if condition */
	jQuery(window).scroll(function () {
	
		if (jQuery(this).scrollTop() > 200) {
		
			jQuery("#back-top").fadeIn();
			
		} else {
		
			jQuery("#back-top").fadeOut();
		}
		
	});
	
	/* scroll body to 0px on click */
	jQuery("#back-top a").click(function () {
		jQuery("body,html").animate({ scrollTop: 0 }, 800 );
		return false;
	});
});

/* popup share post */
function social_share(data) {
    window.open( data, "fbshare", "height=450,width=760,resizable=0,toolbar=0,menubar=0,status=0,location=0,scrollbars=0" );
}