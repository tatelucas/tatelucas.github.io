// ajaxLoop.js
jQuery(function($){
    var offset 	= 1;
    var $window = $(window);
    var $content= $('#masonry-1');
	var $tombol = $("#more-post button");
	//var $textOnLoad 	= masonryAjax.textOnLoad;
	//var $textOnReady 	= masonryAjax.textOnReady;
	//var $textNoPost 	= masonryAjax.textNoPost;
	
    var load_posts = function(){
		console.log(offset);
            $.ajax({
                type       : "POST",
                data       : { 
					action: "newsrightMorePostMasonry", 
					offset: offset,
					content: $tombol.data('content')
				},
                dataType   : "html",
				cache: false,
				async: false,
                url        : masonryAjax.base_url,
                beforeSend : function(){
                   
                },
                success    : function(data){
				
					
					var $newItems = $(data); 
					
					if ($newItems.size()){
						var $moreBlocks = jQuery( data ).filter('article.type-post');
						$moreBlocks.imagesLoaded( function() {
						
						// Append new blocks
					    $content.append( $moreBlocks );

					    // Have Masonry position new blocks
					    $content.masonry( 'appended', $moreBlocks );
						
						$tombol.removeClass('more_loading').html(masonryAjax.textOnReady);
						});
					}
					else{
						$tombol.html(masonryAjax.textNoPost);
						setTimeout( function(){
							$tombol.parent('.load-more').hide();
						},2000);
					}
                },
				
                error     : function(jqXHR, textStatus, errorThrown) {
					$tombol.removeClass('more_loading').html(masonryAjax.textOnReady);
                    alert(jqXHR + " :: " + textStatus + " :: " + errorThrown);
                }
        });
    }
	
	$tombol.click(function(){
        offset++;
		$tombol.addClass('more_loading').html(masonryAjax.textOnLoad);	
		load_posts();
		return false;
		
	});
 
}); 