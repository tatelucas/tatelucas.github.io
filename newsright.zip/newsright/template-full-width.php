<?php 
/*
	Template name: Full Width
*/
get_header(); ?>

<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">
				<div class="main_full_width">
					<?php while (have_posts()) : the_post(); ?> 	
						<?php 
						the_title(
							'<div class="header-feature"><h2 class="mb0">',
							'</h2></div>'
						);  ?>
						<div <?php post_class(); ?>>	
							<?php the_content();?>
							<?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages : ', 'mtcframework' ), 'after' => '</div>' ) ); ?>
						</div>	
						
						
					<?php endwhile; ?>
				</div><!-- end main -->				
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>
