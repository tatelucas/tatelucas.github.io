<?php if ( !is_single() ) { ?>
<div <?php post_class(); ?>>
	<div class="post-media">
		<?php do_action('post-media'); ?>
	</div>
	<div class="post-content">
		<?php do_action('post-content'); ?>
	</div>
</div>
<?php } else {  


	global $post;  
	$the_content = get_the_content('',true) ;
	$the_content = apply_filters( 'the_content', $the_content );
	$the_content = str_replace( ']]>', ']]&gt;', $the_content );
	$embed_code  = rwmb_meta( 'mtc_embed_code', 'type=text' ); 
	
	if(function_exists('get_media_embedded_in_content')){
		$media = get_media_embedded_in_content($the_content,'iframe');
		if(!empty($media)){
			$pc = explode('</iframe>',$media[0]);
			$embed_code = $pc[0].'</iframe>';
			$the_content = str_replace( $embed_code, '', $the_content );
		} 
	}
	?>
	
	<div <?php post_class(); ?>>
	
		<?php the_title('<div class="header-feature"><h2 class="mb0">','</h2></div>'); ?>
		
		<div class="meta">
			<?php echo __('by','mtcframework');?> <?php the_author_posts_link(); ?> /
			<a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php the_time(get_option('date_format')); ?></a>
			<span class="the-category"><?php the_category(', '); ?></span>
			<span class="count-comments"><?php comments_number( 'No Comments', 'One Comments', '% Comments' ); ?></span>
			<?php do_action('single-post-meta'); ?>
		</div>
		
		
		<?php if(!empty($embed_code)){ echo $embed_code; } ?>

		<div class="storycontent">
			<div class="entry">
				<?php do_action('single_before_content'); ?>
				<?php echo $the_content ; ?>
				<?php do_action('single_after_content'); ?>
			</div>	
		</div>

		<div class="storycontent">
			<?php comments_template(); ?> <div class="spacer"></div>
		</div>
		
	</div>
<?php }   ?>