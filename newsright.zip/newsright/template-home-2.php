<?php 
/*
	Template name: Home - Masonry 1
*/


get_header(); 

global $post;
global $smof_data;

$args_slider = array(	
		'posts_per_page'	=> get_option('posts_per_page'),
		'post_type' 		=> 'post',
		'order'				=> 'DESC', 
		'orderby' 			=> 'post_date',
		/* 'ignore_sticky_posts' => 1 */
	);
query_posts($args_slider);

wp_enqueue_script( 'more-post', get_template_directory_uri() . '/js/more-post.js', 'theme' ,true);

$data_ajax = array(
		'base_url' 		=> admin_url( 'admin-ajax.php' ),
		'textOnLoad' 	=> __('Loading...','mtcframework'),
		'textOnReady' 	=> __('Load More','mtcframework'),
		'textNoPost' 	=> __('Post no more...','mtcframework'),
	);
wp_localize_script( 'more-post', 'masonryAjax', $data_ajax );
?>
<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">
			<section class="masonry-1" id="masonry-1">
				<?php while (have_posts()) : the_post();  ?>
				<?php get_template_part('more-content-masonry-1');?>
				<?php endwhile;  ?>
				<?php wp_reset_query();  ?>
			</section>
			<div id="more-post" class="load-more text-center">
				<button data-content="more-content-masonry-1" class="btn btn-danger btn-large"><?php echo __('Load More','mtcframework'); ?></button>
			</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>