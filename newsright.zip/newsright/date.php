<?php get_header(); ?>

<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">
				<div class="main">
					<?php do_action('before_main_content'); ?>
					<div class="main-content">
						<div class="header-feature">
								<?php if ( is_day() ) : ?>
									<span><?php echo __('Daily Archives :', 'mtcframework');?></span>
									<h2 class="mb0"><?php echo get_the_date(); ?></h2>
								<?php elseif ( is_month() ) : ?>
									<span><?php echo __('Monthly Archives :', 'mtcframework');?></span>
									<h2 class="mb0"><?php echo get_the_date( _x( 'F Y', 'monthly archives date format', 'mtcframework' ) ); ?></h2>
								<?php elseif ( is_year() ) : ?>
									<span><?php echo __('Yearly Archives :', 'mtcframework');?></span>
									<h2 class="mb0"><?php echo get_the_date( _x( 'Y', 'yearly archives date format', 'mtcframework' ) ); ?></h2>
								<?php else : ?>
									<h2 class="mb0"><?php _e( 'Blog Archives', 'mtcframework' ); ?></h2>
								<?php endif; ?>
						</div>
						
						<?php if ( have_posts() ) : ?>
							<div class="main-content">
							<?php while ( have_posts() ) : the_post(); ?>
								<?php get_template_part( 'content'); ?>
							<?php endwhile; ?>
							</div><div class="spacer"></div>
						<?php else : ?>
							<?php  get_template_part( 'content', 'none' ); ?>
						<?php endif; ?>
						
					</div>
					<?php do_action('after_main_content'); ?>
				
				</div><!-- end main -->				
				<?php get_template_part('sidebar');?>	
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>