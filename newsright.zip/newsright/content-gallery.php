<?php if ( !is_single() ) { ?>
<div <?php post_class(); ?>>
	<div class="post-media">
		<?php do_action('post-media'); ?>
	</div>
	<div class="post-content">
		<?php do_action('post-content'); ?>
	</div>
</div>
<?php } else {  ?>	
	<div <?php post_class(); ?>>

		<?php the_title('<div class="header-feature"><h2 class="mb0">','</h2></div>'); ?>
		
		<div class="meta">
			<?php echo __('by','mtcframework');?> <?php the_author_posts_link(); ?> /
			<a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php the_time(get_option('date_format')); ?></a>
			<span class="the-category"><?php the_category(', '); ?></span>
			<span class="count-comments"><?php comments_number( 'No Comments', 'one Comments', '% Comments' ); ?></span>
			<?php do_action('single-post-meta'); ?>
		</div>
		
		<div class="post_thumb">
			<div class="mask"></div>
			<?php if ( has_post_thumbnail() ) { ?>
				<?php the_post_thumbnail('large'); ?>
			<?php } else{ ?>
				<img src="<?php echo get_template_directory_uri().'/img/default_thumbnail_large.jpg'; ?>" alt="<?php the_title( ); ?>">
			<?php } ?>
		</div>
		<?php 
		/* <div class="post-media single-post-slier">
			<div id="post-slide-<?php the_ID(); ?>" class="carousel slide">
				<!-- Carousel items -->
				<?php 
				$gallery = get_post_galleries( $post ,false);
				if($gallery){
					$image_list = '<div class="carousel-inner">';
					
					$galle = explode(',',$gallery[0]['ids']);
					$i=0;
					foreach($galle as $dd){
						$image_list .= '<div class="item';
						$image_list .= ($i==0) ? ' active' :'';
						$get_images = 'full';
						$image_list .= '">'.wp_get_attachment_image( $dd,$get_images  ).'</div>';
					
						$i++;
					}
					
					$image_list .= '</div>';
					echo $image_list;
				}

				?>
				<!-- Controls -->
				<a class="left carousel-control" href="#post-slide-<?php the_ID(); ?>" data-slide="prev"><i class="icon-chevron-left"></i></a>
				<a class="right carousel-control" href="#post-slide-<?php the_ID(); ?>" data-slide="next"><i class="icon-chevron-right"></i></a>
			</div>	
		</div> */
		?>
		
		<div class="storycontent">
			<div class="entry">
				<?php do_action('single_before_content'); ?>
				<?php the_content() ; ?>
				<?php do_action('single_after_content'); ?>
			</div>	
		</div>
		<div class="storycontent">
			<?php comments_template(); ?> <div class="spacer"></div>
		</div>
	</div>
<?php }   ?>