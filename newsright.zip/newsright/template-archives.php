<?php 
/*
	Template name: Archives
*/
get_header(); ?>

<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">
				<div class="main">
					<?php while (have_posts()) : the_post(); ?> 	
						<?php 
						the_title(
							'<div class="header-feature"><span>'. __('Post Timeline','mtcframework') .'</span><h2 class="mb0">',
							'</h2></div>'
						);  ?>	
		
							<?php the_content(); ?>
							<?php 
							global $wpdb;
							$query = "SELECT YEAR(post_date) AS `year`, MONTH(post_date) AS `month`, date_format(post_date,'%M') AS `month_text` FROM $wpdb->posts  WHERE post_type = 'post' AND post_status = 'publish' GROUP BY YEAR(post_date), MONTH(post_date) ORDER BY post_date DESC";
							$archive = $wpdb->get_results($query);
							echo'<ul class="list_archive">';
							foreach($archive as $ar){
								echo'<li> <h3>'.$ar->month_text.' '.$ar->year.'</h3>';
								$query = "SELECT DISTINCT ID, post_title, DAY(post_date) AS post_date, date_format(post_date,'%b') AS `month_text` FROM $wpdb->posts WHERE post_type = 'post' AND post_status = 'publish' AND YEAR(post_date)='".$ar->year."' AND MONTH(post_date)='".$ar->month."' ORDER BY DAY(post_date) DESC";
								$post_archive = $wpdb->get_results($query);
								echo '<ul>';
									foreach($post_archive as $pa){
										//print_r( $pa);
										echo'<li class="link-2"><a href="'. post_permalink( $pa->ID ) .'" title="'.$pa->post_title.'"><span>'.$pa->month_text .' '. $pa->post_date.'</span> '.$pa->post_title.'</a></li>';
									}
								echo'</ul>';
								echo'</li>';
							}
							echo'</ul>';
							?>
							
				
					<?php endwhile; ?>
				</div><!-- end main -->				
	
				<?php get_template_part('sidebar');?>
					
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>
