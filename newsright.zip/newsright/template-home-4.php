<?php 
/*
	Template name: Home Full Width
*/


get_header(); ?>
<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">
				<?php 
					/* Load Slideshow */
					if($smof_data['switch_slider']){
						get_template_part('slider1');
					}
				
				?>
				<div class="main-full-width">
					<?php

					/* Load Scroll Box */
					if($smof_data['switch_scrolling_box']){
						$args = array(
							'style'		=> $smof_data['scrolling_box_style'], 
							'per_page'	=> $smof_data['scrolling_box_count'], 
							'title'		=> $smof_data['scrolling_box_title']
						);
						mtc_scrolling_box($args); 
					}
					
					/* Load News Box*/					
					mtc_news_boxs_v3(); 
					
					/* Load News Tabs */	
					mtc_news_tab(); 
					
					
					mtc_news_in_picture();
					
					?>
				</div><!-- end main -->								
			</div>
		</div>
	</div>
	
	
	<?php mtc_random_author(); ?>
	
	
</div>
<?php get_footer(); ?>