<?php get_header(); ?>
<div class="wrapper _author_content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12">
				<div class="box_author">
					<div class="author_side text-center">
						<?php 
					
						$curauth = (get_query_var('author_name')) ? get_user_by('slug', get_query_var('author_name')) : get_userdata(get_query_var('author'));
						echo mtc_get_avatar($curauth,'160');
						
						
						?>
					</div>
						
					<div class="author_info">
						<h2 class="author_name"><?php  echo $curauth->display_name; ?></h2>
						<div class="author-meta">
							<?php echo $curauth->roles[0];?> /
							<span class="num_of_entry">
								<?php echo number_format_i18n( get_the_author_posts() ); ?>
								<?php _e(' Entries', 'mtcframework'); ?>
							</span>
						</div>
						<p><?php echo $curauth->description; ?></p>
					</div>
					
					
					<div class="author_socmed">
						<ul class="socmed">
						<?php 
							global $socmed_user;
							foreach($socmed_user as $soc){
								$socmed_link = get_the_author_meta($soc['id'],$curauth->ID);
								if(!empty($socmed_link)){
									$class_icon = str_replace('-','_',$soc['icon']);
									echo'<li><a class="mtc_social_icon social_'.$class_icon.'" 
									href="'.$socmed_link.'" target="_blank"><i class="icon '.$soc['icon'].'" title="'.$soc['title'].'"></i>&nbsp;</a></li>';
								}
							} 
						?>
						</ul>
					</div> 
				</div> 
			</div>
		</div>
	</div>
</div>
			
<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">
				<div class="main">	
					<?php if ( have_posts() ) : ?>
					<div class="list-post-author">
					<?php while ( have_posts() ) : the_post(); ?>
						<div class="post-list-tab">
							<div class="thumb">
								<?php if ( has_post_thumbnail() ) { ?>
									<?php the_post_thumbnail('slider-thumb'); ?>
								<?php } else{ ?>
									<img src="<?php echo get_template_directory_uri().'/img/default_thumbnail_large.jpg'; ?>" alt="<?php the_title( ); ?>">
								<?php } ?>
								<div class="overlay">
									<a href="<?php the_permalink(); ?>" class="link"><?php echo __('Read More','mtcframework');?></a>
								</div>
							</div>
							
							<div class="tab_list_content">
								<?php do_action('news_tab_list_before_title'); ?>
								<h3 class="link-2"><a href="<?php echo get_permalink(); ?>"><?php the_title( ); ?></a></h3>
								<?php do_action('news_tab_list_after_title'); ?>
									
							</div>
						</div>
					<?php endwhile; ?>
					</div><div class="spacer"></div>
					<?php else : ?>
						<?php  get_template_part( 'content', 'none' ); ?>
					<?php endif; ?>
					
					<div class="pagination">
						<?php if (function_exists("pagination")) { pagination(); } ?>
					</div>
				
				</div><!-- end main -->				
				<?php get_template_part('sidebar');?>	
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>