<div class="slider" id="lates-home-2">
<?php 
	global $post;
	global $smof_data;
	$carousel = $caption = '';
	$s = 1;
	
	$args_slider = array(	
		'posts_per_page'	=> $smof_data['slider_count'], 
		'post_type' 		=> 'post',
		'order'				=> 'DESC', 
		'orderby' 			=> 'post_date',
		'ignore_sticky_posts' => 1
	);
	
	$content_slider = $smof_data['slider_content'];
					
	if('latest' == $content_slider['content']){
	
	}
	else if('category' == $content_slider['content']){
		$args_slider['cat'] = $content_slider['category'];
		
	}
	
	else if('tag' == $content_slider['content']){
		$args_slider['tag'] = $content_slider['tag'];
	}
					
	query_posts($args_slider);
	
	global $post;
	while (have_posts()) : the_post(); 
		$class ='';
		if($s==2){
			$class='sbig';
		}
		?>
		<div <?php post_class($class); ?>>
			<div class="post-media-slider">
				<div class="thumb">
					<?php if ( has_post_thumbnail() ) { ?>
						<?php the_post_thumbnail('medium-square'); ?>
					<?php } else{ ?>
							<img src="<?php echo get_template_directory_uri().'/img/default-blog-thumb.jpg'; ?>" alt="<?php the_title( ); ?>">
					<?php } ?>
				</div>
				<?php post_media_overlay_title(); ?>
			</div>
		</div>
	<?php	
	$s++;
	endwhile; 
	wp_reset_query();
?>
</div><!-- END slider-->