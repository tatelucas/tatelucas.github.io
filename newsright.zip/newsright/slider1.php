<div class="slider1">
<?php 
	global $post;
	global $smof_data;
	$carousel = $caption = '';
	$s = 1;
	
	$args_slider = array(	
		'posts_per_page'	=> $smof_data['slider_count'], 
		'post_type' 		=> 'post',
		'order'				=> 'DESC', 
		'orderby' 			=> 'post_date',
		'ignore_sticky_posts' => 1
	);
	
	$content_slider = $smof_data['slider_content'];
					
	if('latest' == $content_slider['content']){
	
	}
	else if('category' == $content_slider['content']){
		$args_slider['cat'] = $content_slider['category'];
		
	}
	
	else if('tag' == $content_slider['content']){
		$args_slider['tag'] = $content_slider['tag'];
	}
					
	query_posts($args_slider);
	
	global $post;
	while (have_posts()) : the_post();
		
		$title 		= get_the_title();
		$excerpt 	= excerpt(20);
		
		if ( has_post_thumbnail() ) {
			$carousel .= get_the_post_thumbnail($post->ID, 'slider-big');
		}
		else{
			$image 		= get_template_directory_uri().'/img/default-slider-big.jpg';
			$carousel .='<img src="'.$image .'"   alt="slide_'. $s .'"  />';
		}
		//$single_cate = single_category_post($post);	
		$caption.='<div class="caption slide_'. $s .'">';
		
			/* if(!empty($single_cate)){
				$caption.='<div class="cate">'.$single_cate.'</div>'; 
			} */
			
			
			
			$caption.='<div class="slider-meta3"><a href="'.get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')).'">'.get_the_time(get_option('date_format')).'</a></div>';
			
			$single_cate = single_category_post();	
			
			$caption.='<h3><a href="'.get_permalink().'">'.$title.'</a></h3>';
			//$caption.='<p>'. $excerpt .'<br /><br /><a href="'.get_permalink().'" class="btn btn-success btn-large">'.__('Read More','mtcframework').'</a></p>';
			if(!empty($single_cate)){
				$caption.='<div class="cate">'.$single_cate.'</div>';
			}
			
		$caption.='</div>';
		
	$s++;
	endwhile; 
	wp_reset_query();
	
	
	
	?>
	<div id="carousel-1">
		<div class="moouse"><?php echo $carousel; ?></div>
	</div>
	<div class="slider1-overlay"></div>
	<div class="slider1-label">Hot News Today</div>
	
	<div id="captions-1">
		<div class="list_c"><?php echo $caption;?></div>
	</div>
	<div class="pager-nav">
		<a href="#" class="nav-prev"><i class="icon-angle-left"></i></a>
		<a href="#" class="nav-next"><i class="icon-angle-right"></i></a>
	</div>
</div><!-- END slider-->

<div class="more-slider">
	<div class="slider-more-header">
		<span>Latest By Category</span>
		<h2>Featured Cover Posts</h2>
	</div>
	<div class="box-more-slider">
	<ul class="foo2">
		<?php 
		$args_slider = array(	
			'posts_per_page'	=> 6, 
			'post_type' 		=> 'post',
			'order'				=> 'ASC', 
			'orderby' 			=> 'post_date',
			'ignore_sticky_posts' => 1
		);
		
		query_posts($args_slider);
	
		global $post;
		while (have_posts()) : the_post();
			if ( has_post_thumbnail() ) {
				$carousel = get_the_post_thumbnail($post->ID, 'slider-thumb');
			}
			else{
				$image 		= get_template_directory_uri().'/img/default-slider-thumb.jpg';
				$carousel ='<img src="'.$image .'"   alt="slide_'. $s .'"  />';
			}
			//$single_cate = single_category_post();	
		?>
		<li>
			<?php list_post_single_tag(); ?>
			<div class="thumb">
				<?php echo $carousel; ?>
				<div class="overlay">
					<a href="<?php the_permalink(); ?>" class="link">Read More</a>
				</div>
			</div>
			<div class="more-content">
				<h2 class="link-2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				
				<div class="meta">
					<?php echo __('by','mtcframework');?> <?php the_author_posts_link(); ?> /
					<a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php the_time(get_option('date_format')); ?></a>
				</div>
				<p><?php echo excerpt(15); ?></p>
			</div>
			
		</li>
		<?php 
		endwhile; 
		wp_reset_query();
		?>
	</ul>
	</div>
	<div class="clearfix"></div>
	<a class="prev" id="foo2_prev" href="#"><i class="icon-angle-left"></i></a>
	<a class="next" id="foo2_next" href="#"><i class="icon-angle-right"></i></a>
</div>