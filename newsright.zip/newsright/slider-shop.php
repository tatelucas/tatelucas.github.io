<div class="post_row pt40">
	<div class="header-feature">
		<div id="nav-slider-latest-product" class="posts-controls slider-nav"></div>
		<span><?php echo __('Latest Product', 'mtcframework');?></span>
		<h2 class="mb0"><?php echo __('Featured Product', 'mtcframework');?></h2>
	</div>
	
	<div class="slide-shop pt20">
		<?php echo do_shortcode('[recent_products per_page="12" columns="3" orderby="date" order="desc"]'); ?>
	</div>
</div>