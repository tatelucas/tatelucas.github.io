<?php get_header(); ?>

<div class="wrapper _content">
	<div class="container">
		<div class="row-fluid">
			<div class="span12 content">
				<div class="main">
				
					<?php do_action('before_main_content'); ?>
					
					<div class="main-content">
						<?php if ( have_posts() ) : ?>
							<?php while ( have_posts() ) : the_post(); ?>
								<?php get_template_part( 'content', get_post_format() ); ?>
							<?php endwhile; ?>
						<?php else : ?>
							<?php  get_template_part( 'content', 'none' ); ?>
						<?php endif; ?>
					</div>
					
					<?php do_action('after_main_content'); ?>
					
				</div><!-- end main -->				
				<?php get_template_part('sidebar');?>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>
							
						