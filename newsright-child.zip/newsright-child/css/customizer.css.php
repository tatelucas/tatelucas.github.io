<?php 

header("Content-type: text/css; charset: UTF-8");
require_once('../../../../wp-load.php');

global $smof_data;





/* load customizer options */
$custom_set = get_option( 'custom_set' );


echo "/* CUSTOM STYLE */\n";

if(isset($smof_data['switch_typography']) && 1 == $smof_data['switch_typography']) {
	$c ="\n";
	$c .= mtc_print_css_typo('body','general_typo');
	$c .= mtc_print_css_typo('input,
							button,
							select,
							textarea, .post-content,.post .post-content .post-meta ,.post-media .overlay,.woocommerce-page ul.products li.product.product-category .overlay .overlay-inner a.button, .woocommerce ul.products li.product.product-category .overlay .overlay-inner a.button, .woocommerce ul.products li.product, .woocommerce-page ul.products li.product,.woocommerce-page ul.products li.product .wrap-product .overlay .item-btn-group a.button, .woocommerce ul.products li.product .wrap-product .overlay .item-btn-group a.button, .masonry-1 article.type-post .thumb .overlay a.link, .masonry-1 article.type-post .thumb .overlay,.tab_content ul.post-list li .thumb .overlay a, .news_block .list_home .thumb .overlay a,
							.block_news .list_home .thumb .overlay a,
							.post-list-tab .thumb .overlay a, .more-slider li .thumb .overlay a, .news_block .list_home .thumb .overlay a,.block_news .list_home .thumb .overlay a,.post-list-tab .thumb .overlay a.tab_content ul.post-list li .thumb .overlay a,ul.author-list li .thumb .overlay a,ul.author-list div.meta,.tab_list_content div.meta,div.tab-controls ul li,ul.list-mini li div.meta,.more-content div.meta,.list_home_content div.meta, .list_home_content p.excerpt','general_typo',true);
	
	
	$c .= mtc_print_css_typo('div.author-detail, .single .post div.meta','general_typo',true);
	
	$c .= mtc_print_css_typo('#menu-menu-top a','f_mainmenu',true);
	
	$c .= mtc_print_css_typo('ul.author-list li .author-conten h3,h3.csw-title,.tab_content ul.post-list li h3.post-title,.post-title, ul.relatepost li h4, .masonry-1 article.type-post .list-content h2, .tab_list_content h3, .list-v3-large .overlay h2, .list-v3-small h3, ul.list-mini li h3, .list_home_content h2, .more-slider li .more-content h2, .slider1 .caption h3','f_post',true);
	
	$c .= mtc_print_css_typo('.main .page, .main_full_width .page, .storycontent .entry','f_postentry');
	
	$c .= mtc_print_css_typo(' .more-slider .slider-more-header h2, div.header-feature h2, .widget h2.widget_title','f_widget');
	$c .= mtc_print_css_typo('.comment-reply-title, .post-relate h3,.more-slider .slider-more-header span,div.header-feature span','f_widget',true);
	
	echo $c."\n";
	
	
	
	if(!empty($smof_data['list_post_title_color'])) {
		echo '
		.widget.widget_footer .post-title a,
		.link-2 a
			{ 
			color:'.$smof_data['list_post_title_color'].'}'; 
	}

	if(!empty($smof_data['list_post_meta_color'])) {
		echo '
		.widget_footer div.meta a, .widget.mtc_recent_post_widget ul li div.meta,
		.list-v3-small div.meta, .list-v3-small div.meta a,
		.list-content div.meta,.list-content div.meta a,
		.tab_list_content div.meta a,.tab_list_content div.meta,
		.more-content div.meta a,.more-content div.meta,
		ul.list-mini li div.meta, ul.list-mini li div.meta a,
		ul.list-mini li div.meta, ul.list-mini li div.meta a,
		.list_home_content div.meta, .list_home_content div.meta a
			{ 
			color:'.$smof_data['list_post_meta_color'].'}'; 
	}

	if(!empty($smof_data['list_post_excerpt_color'])) {
		echo '
		.list_home_content p.excerpt
			{ 
			color:'.$smof_data['list_post_excerpt_color'].'}'; 
	}
}

else{
	?>
	
	/* 
		@import url(http://fonts.googleapis.com/css?family=PT+Sans:400,700);
		@import url(http://fonts.googleapis.com/css?family=Adamina); 
	*/
	
	@import url(http://fonts.googleapis.com/css?family=PT+Sans:400,700);
	@import url(http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,700);
	@import url(http://fonts.googleapis.com/css?family=Oswald:400,300);
	<?php
}




echo "\n";





/* = Show custom background images from theme options
*********************************************************/
if(!empty($smof_data['switch_custom_bg'])) {
	echo 'body{';
	
	if(!empty($smof_data['custom_bg_upload'])) :
		echo 'background-image:url('.$smof_data['custom_bg_upload'].');';
	else: 
		if(!empty($smof_data['custom_bg'])) :
			echo 'background-image:url('.$smof_data['custom_bg'].');';
		endif;
	endif;
		echo 'background-repeat:'.$smof_data['custom_bg_repeat'].';';
		echo 'background-position:'.$smof_data['custom_bg_pos'].';';
		echo 'background-attachment:'.$smof_data['custom_bg_attach'].';';
		
		if('fixed' == $smof_data['custom_bg_attach']){
			echo 'background-size:cover;';
		}
	echo '}';
	
} else { 
	
}
	

	
	
	
	
	
	
	
function hex2rgba($hex,$alpha = '0.8'){
	$rgb = hex2rgb($hex);
	return 'rgba('.$rgb[0].','.$rgb[1].','.$rgb[2].','.$alpha.')';
}
	
	
/* Show custom  themes from Themes Customize */
/* Body */
if(!empty($custom_set['body'])){
	echo'body{ background-color:#'.$custom_set['body'].'}';
}



/* = COLOR 
*************************************  */
if(!empty($custom_set['color'])): 
	$rgba = hex2rgba($custom_set['color'],'0.9');	
	
echo'
	.bbp-login-form .bbp-submit-wrapper #user-submit,
	._header_top,
	div.review-item .progress .bar,
	.summary-score , 
	.btn-danger ,
	#back-top a,
	.masonry-1 article.type-post .ribbon-label,
	.tab_list_content .ribbon-label,
	.post_row.block_news .list_home .ribbon-label,
	.more-slider li .ribbon-label,
	.woocommerce span.onsale, 
	.woocommerce-page span.onsale,
	.woocommerce nav.woocommerce-pagination ul li span.current,.woocommerce nav.woocommerce-pagination ul li a:hover,.woocommerce nav.woocommerce-pagination ul li a:focus,.woocommerce #content nav.woocommerce-pagination ul li span.current,.woocommerce #content nav.woocommerce-pagination ul li a:hover,.woocommerce #content nav.woocommerce-pagination ul li a:focus,.woocommerce-page nav.woocommerce-pagination ul li span.current,.woocommerce-page nav.woocommerce-pagination ul li a:hover,.woocommerce-page nav.woocommerce-pagination ul li a:focus,.woocommerce-page #content nav.woocommerce-pagination ul li span.current,.woocommerce-page #content nav.woocommerce-pagination ul li a:hover,.woocommerce-page #content nav.woocommerce-pagination ul li a:focus,
	.box_list.news_block > .list_home .ribbon-label,
	#data-cart p.buttons a.button.checkout,
	.woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce #respond input#submit.alt, .woocommerce #content input.button.alt, .woocommerce-page a.button.alt, .woocommerce-page button.button.alt, .woocommerce-page input.button.alt, .woocommerce-page #respond input#submit.alt, .woocommerce-page #content input.button.alt
	{ 
		background:#'.$custom_set['color'].'}'; 
		
		
		
echo'
	#commentform p.form-submit input[type="submit"],
	#bbpress-forums #bbp-search-form input.button,
	.pagination ul > li > a:hover, .pagination ul > li > a:focus, .pagination ul > .active > a, .pagination ul > .active > span,
	.pagination ul > .disabled > span,
	.pagination ul > .disabled > a,
	.pagination ul > .disabled > a:hover,
	.pagination ul > .disabled > a:focus,
	.header_top ul.nav
		{ background-color:#'.$custom_set['color'].';}';
		
		
		
echo'
	.masonry-1 article.type-post .ribbon-label:before,
	.tab_list_content .ribbon-label:before,
	.post_row.block_news .list_home .ribbon-label:before ,
	.more-slider li .ribbon-label:before,
	.woocommerce span.onsale:before,
	.woocommerce-page span.onsale:before,
	.box_list.news_block > .list_home .ribbon-label:before
	{
		border-color: transparent #'.$custom_set['color'].' transparent transparent;}';
	
echo'
	.list-v3-large .overlay a.link:hover,
	ul.author-list li .thumb .overlay a:hover,
	.news_block .list_home .thumb .overlay a:hover,
	.block_news .list_home .thumb .overlay a:hover,
	.post-list-tab .thumb .overlay a:hover,
	.widget_footer .tagcloud a:hover,
	.post_panel ul li a:hover,
	.tagcloud a:hover,
	.masonry-1 article.type-post .thumb .overlay a.link:hover,
	.post-media .overlay a:hover,
	.post-media-slider .overlay a:hover,
	.woocommerce-page ul.products li.product.product-category .overlay .overlay-inner a.button:hover, 
	.woocommerce ul.products li.product.product-category .overlay .overlay-inner a.button:hover,
	.woocommerce-page ul.products li.product .wrap-product .overlay .item-btn-group  a.button:hover,
	.woocommerce ul.products li.product .wrap-product .overlay .item-btn-group a.button:hover
	{
		border-color:#'.$custom_set['color'].';
		background:#'.$custom_set['color'].';
	}';	
	
echo'
	div.tab-controls ul li.active,
	.more-slider .slider-more-header,
	.pagination ul > li > a, 
	.pagination ul > li > span,
	h2.widget_title,
	.more-slider a.prev, 
	.more-slider a.next,
	.slider-nav a,
	div.header-feature,
	.post_panel ul li a,
	.post-relate h3,
	h3#comments, h3#reply-title,
	#content div.product .product_title, .woocommerce div.product .product_title, .woocommerce-page #content div.product .product_title, .woocommerce-page div.product .product_title,
	.woocommerce nav.woocommerce-pagination ul li a,.woocommerce nav.woocommerce-pagination ul li span,.woocommerce #content nav.woocommerce-pagination ul li a,.woocommerce #content nav.woocommerce-pagination ul li span,.woocommerce-page nav.woocommerce-pagination ul li a,.woocommerce-page nav.woocommerce-pagination ul li span,.woocommerce-page #content nav.woocommerce-pagination ul li a,.woocommerce-page #content nav.woocommerce-pagination ul li span,
	#bbpress-forums fieldset.bbp-form legend,
	.box-widget-footer,
	ul.list_archive li h3,
	ul.list_archive,
	.tagcloud a
	{ 
		border-color:#'.$custom_set['color'].'}'; 
		
echo'#bbpress-forums li.bbp-header	{ border-bottom-color:#'.$custom_set['color'].'}'; 
 
echo'
	a,
	.link-2 a:hover,
	.widget_footer ul.tabs li.active a,
	nav.footer-navigation li:hover > a,
	.woocommerce div.product span.price, .woocommerce div.product p.price, .woocommerce #content div.product span.price, .woocommerce #content div.product p.price, .woocommerce-page div.product span.price, .woocommerce-page div.product p.price, .woocommerce-page #content div.product span.price, .woocommerce-page #content div.product p.price,
	.woocommerce ul.products li.product .price, .woocommerce-page ul.products li.product .price,
	.slider-nav a,
	ul.list_archive li h3:after,
	ul.list_archive li ul li:after,
	.more-slider a.prev, 
	.more-slider a.next,
	.rating-view span.star.active~span.star:before,
	.rating span.star:hover:before,
	.rating span.star:hover~span.star:before,
	.list_home_content div.meta a:hover,
	.single .post div.meta a:hover,
	.list-v3-large .overlay .meta a:hover,
	.list-v3-small div.meta a:hover,
	.list-content div.meta a:hover,
	.tab_list_content div.meta a:hover,
	ul.list-mini li div.meta a:hover,
	.more-content div.meta a:hover
	
		{color: #'.$custom_set['color'].'}';
		
echo '
	.woocommerce nav.woocommerce-pagination ul li a,
	.woocommerce #content nav.woocommerce-pagination ul li a,
	.woocommerce-page nav.woocommerce-pagination ul li a,
	.woocommerce-page #content nav.woocommerce-pagination ul li a,
	
	nav.main-navigation ul.nav li.current-menu-item a:hover, 
	nav.main-navigation ul.nav .current-menu-item a
	{color: #'.$custom_set['color'].'!important}';
	
	
echo '
	.masonry-1 article.type-post .carousel .carousel-control{
		background:'. $rgba .';
	}
';



endif; 
/* END COLOR */



/* COLOR 2 */
if(!empty($custom_set['color2'])) {

echo '
	nav.main-navigation li:hover > a, 
	nav.main-navigation ul ul :hover > a,
	.widget_footer  div.meta a:hover
	{ color:#'.$custom_set['color2'].'}'; 	
	
echo '
	.bbp-login-form .bbp-submit-wrapper #user-submit:hover,
	.btn-danger:hover, 
	#back-top a:hover, 
	.header_top li:hover > a, .header_top ul ul :hover > a,
	.header_top > ul li > ul,
	.header_top ul.nav li.current-menu-item,
	#data-cart p.buttons a.button.checkout:hover,
	.woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce #content input.button.alt:hover, .woocommerce-page a.button.alt:hover, .woocommerce-page button.button.alt:hover, .woocommerce-page input.button.alt:hover, .woocommerce-page #respond input#submit.alt:hover, .woocommerce-page #content input.button.alt:hover
	{ background:#'.$custom_set['color2'].'}'; 
	
echo '
	.topnav_toggle,
	#commentform p.form-submit input[type="submit"]:hover,
	#bbpress-forums #bbp-search-form input.button:hover
	{ background-color:#'.$custom_set['color2'].'}'; 	
	
echo '
	nav.main-navigation > ul li > ul{
		border-top-color:#'.$custom_set['color2'].'}';
		
echo '
	.slider-nav a:hover,
	.more-slider a.prev:hover,
	.more-slider a.next:hover
	{ 
		border-color:#'.$custom_set['color2'].';
		background:#'.$custom_set['color2'].'}'; 
/* 
echo'
	#witgetsearch button.btn:hover
	{border-color: #'.$custom_set['color2'].'!important }'; 	
	

	
$rgba = hex2rgba($custom_set['color2'],'0.9');		
echo'
	.slider .pager-nav a:hover,
	.slider3 .pager-nav a:hover
		{ background:'.$rgba.'}';  */

}
/* END COLOR 2*/
	
	
	
	
	
	
/* = color3
****************************************************/
if(!empty($custom_set['color3'])) {

echo'
	.header_top ul ul li a:hover,
	.topnav_toggle:hover 
		{ background-color:#'.$custom_set['color3'].' }';


}
	

	

/* = layout_style
**********************************************/
if('wide'==$smof_data['layout_style']){
	//echo '.boxed ._content{background:transparent!important}';
	//echo '.boxed:not(.active){background:transparent!important}';
	//echo '.boxed{background:transparent!important}';
}





