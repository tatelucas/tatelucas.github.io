jQuery(function () {
	
	$('.tab-controls a').click(function () {
		$(this).parents('.tab-controls').find('li').removeClass('active');
		$(this).parent().addClass('active');
		
		/* var count	= $(this).data('count'); */
		var cat		= $(this).data('cat');
		var target	= $(this).data('target');
		var action	= $(this).data('action');
		$target 	= $('#'+target);
		
		$.ajax({
				type: "POST",
				url: themeSetting.base_url,
				data: { 
					action: action, 
					/* count: count,  */
					cat:cat 
				},
				cache: false,
				async: false,
				beforeSend: function() {
					//$('#tab-content').html('Loading...');
					//var $lessBlocks = $target.find('div.post-list-tab');
					
					// Remove blocks
					$target.addClass('loading');;
					
					$target.html('');
				},
				success: function(result) {
					$target.removeClass('loading').html('');
					
					// Make jQuery object from HTML string
					if('mtc-news-pict' == action){
						var $moreBlocks = jQuery( result ).filter('.list_mini');
					}else{
						var $moreBlocks = jQuery( result ).filter('div.post-list-tab');
					}
					//
					
					
					// Append new blocks
					//$target.append($moreBlocks);//.masonry().masonry('reloadItems');
					// $target.masonry('reloadItems');

					// Have Masonry position new blocks
					$moreBlocks.each(function(){
						$target.append($(this) );
					});
					
				
				
				},
				error: function(result) {
					console.log(result);
					alert("some error occured, please try again");
				}
			}); 
			
			return false;
	});
});